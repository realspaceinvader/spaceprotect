# Changelog

## 1.0.0 – 2026-10-12

First public release. / Erste öffentliche Version.

- Daily limit per weekday, extra time for today, warnings and automatic logoff
- Background process as SYSTEM scheduled task (starts at boot, restarts on failure)
- Tray icon for the supervised account
- Password-protected admin app (German / English, light / dark)
- Single `Spaceprotect.exe`, all files in `C:\Program Files\Spaceprotect`
- 25 automated tests
