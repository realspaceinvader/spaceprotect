"""Baut die einzige Spaceprotect.exe nach release/ (ein Datei, Logo eingebettet, Windows x64)."""

import os
import shutil

import PyInstaller.__main__

ROOT = os.path.dirname(os.path.abspath(__file__))
os.chdir(ROOT)

for folder in ("build", "release"):
    shutil.rmtree(folder, ignore_errors=True)

ICON = os.path.join(ROOT, "assets", "spaceprotect.ico")

PyInstaller.__main__.run([
    "--noconfirm",
    "--clean",
    "--onefile",
    "--noconsole",
    "--name", "Spaceprotect",
    "--icon", ICON,
    "--add-data", f"{ICON};assets",
    "--add-data", f"{os.path.join(ROOT, 'assets', 'spaceprotect-logo.png')};assets",
    "--collect-all", "customtkinter",
    "--hidden-import", "win32timezone",
    "--distpath", "release",
    "--workpath", "build",
    "--specpath", "build",
    "launcher.py",
])

print("Fertig: release\\Spaceprotect.exe")
