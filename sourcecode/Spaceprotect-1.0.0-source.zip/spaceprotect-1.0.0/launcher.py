"""Einstiegspunkt für PyInstaller. Startet die Oberfläche oder den Dienst (--service)."""

from spaceprotect.__main__ import main

if __name__ == "__main__":
    main()
