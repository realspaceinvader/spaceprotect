"""Spaceprotect – Kinderzeit-Begrenzung für Windows."""
