"""Einstiegspunkt. Ohne Argumente: Verwaltungsoberfläche. Mit --service: Windows-Dienst."""

import sys


def main() -> None:
    if "--service" in sys.argv:
        from .service import run_service_mode

        run_service_mode()
        return

    if "--agent" in sys.argv:
        from .agent import run_agent

        run_agent()
        return

    from .gui import run

    run()


if __name__ == "__main__":
    main()
