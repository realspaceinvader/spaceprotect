"""Hinweis-Symbol im Infobereich. Startet bei jeder Anmeldung eines Benutzers.

Zeigt, dass die Computerzeit begrenzt wird. Bietet keine Einstellungen und keinen Beenden-Eintrag.
„Verwaltung öffnen“ startet die Verwaltung; diese verlangt Administratorrechte (UAC) und das Passwort.
"""

from __future__ import annotations

import os
import subprocess
import sys
import threading
import time
import winreg

import pystray
from PIL import Image

from . import paths

TOOLTIP = "Spaceprotect – deine Computerzeit wird begrenzt"
NOTIFY_KEY = r"Control Panel\NotifyIconSettings"


def promote_tray_icon(attempts: int = 12, delay: float = 2.0) -> None:
    """
    Windows 11 versteckt neue Symbole im Überlauf-Bereich. Das Symbol dieses Programms wird in der
    Registrierung des aktuellen Benutzers als „hochgestuft“ (sichtbar) markiert.
    """
    for _ in range(attempts):
        time.sleep(delay)
        try:
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, NOTIFY_KEY, 0, winreg.KEY_READ) as root:
                index = 0
                while True:
                    try:
                        name = winreg.EnumKey(root, index)
                    except OSError:
                        break
                    index += 1
                    try:
                        with winreg.OpenKey(root, name, 0, winreg.KEY_READ | winreg.KEY_SET_VALUE) as entry:
                            executable, _ = winreg.QueryValueEx(entry, "ExecutablePath")
                            if str(executable).lower().endswith("spaceprotect.exe"):
                                winreg.SetValueEx(entry, "IsPromoted", 0, winreg.REG_DWORD, 1)
                    except OSError:
                        continue
        except OSError:
            continue


def _open_admin(_icon, _item) -> None:
    subprocess.Popen([sys.executable], close_fds=True)


def run_agent() -> None:
    logo = Image.open(paths.resource_path(os.path.join("assets", "spaceprotect-logo.png")))
    image = logo.convert("RGBA").resize((64, 64))
    menu = pystray.Menu(
        pystray.MenuItem("Spaceprotect: Schutz aktiv", None, enabled=False),
        pystray.Menu.SEPARATOR,
        pystray.MenuItem("Verwaltung öffnen (Passwort nötig)", _open_admin),
    )
    icon = pystray.Icon("Spaceprotect", image, TOOLTIP, menu)
    threading.Thread(target=promote_tray_icon, name="promote-tray-icon", daemon=True).start()
    icon.run()
