"""Reine Geschäftslogik von Spaceprotect (keine Windows-Abhängigkeiten, vollständig testbar)."""

from __future__ import annotations

import datetime as dt
import hashlib
import hmac
import math
import secrets
from dataclasses import dataclass

__version__ = "1.0.0"

PBKDF2_ITERATIONS = 600_000
MIN_PASSWORD_LENGTH = 12
MAX_MINUTES = 24 * 60
MAX_GAP_SECONDS = 30.0          # Lücken darüber gelten als Schlaf/Ruhezustand/Hänger und werden nicht gezählt
CLOCK_TOLERANCE_SECONDS = 5.0   # Abweichung Wanduhr vs. Monotonuhr, ab der ein Zeitsprung protokolliert wird
CHECKPOINT_SECONDS = 10.0       # Abstand der Zwischenspeicherungen laufender Zeit
LOGOFF_GRACE_SECONDS = 5.0      # Anzeigezeit der Ablaufmeldung vor der Abmeldung
LOGOFF_RETRY_SECONDS = 15.0     # Wartezeit zwischen Abmeldeversuchen
MAX_LOGOFF_ATTEMPTS = 5         # danach keine Versuche mehr (keine Endlosschleife)
POLL_SECONDS = 5.0              # Prüfintervall des Dienstes


class ConfigError(ValueError):
    """Ungültige Eingabe. Die Meldung ist für die Oberfläche bestimmt."""


@dataclass(frozen=True)
class DayLimit:
    """Zeitlimit eines Wochentags. enabled=False bedeutet: keine Begrenzung an diesem Tag."""

    enabled: bool
    minutes: int

    def validate(self) -> None:
        if isinstance(self.minutes, bool) or not isinstance(self.minutes, int):
            raise ConfigError("Das Zeitlimit muss eine ganze Zahl von Minuten sein.")
        if not 0 <= self.minutes <= MAX_MINUTES:
            raise ConfigError("Das Zeitlimit muss zwischen 0 und 1440 Minuten liegen.")


# Index 0 = Montag ... 6 = Sonntag (entspricht datetime.weekday())
DEFAULT_PLAN: tuple[DayLimit, ...] = (
    DayLimit(True, 90),
    DayLimit(True, 90),
    DayLimit(True, 120),
    DayLimit(True, 90),
    DayLimit(True, 120),
    DayLimit(True, 180),
    DayLimit(True, 180),
)

DEFAULT_TEXTS: dict = {
    "warn_minutes": [10, 2],
    "warn": "Du hast noch {RestMinuten} Minuten Computerzeit für heute.",
    "final": "Deine Computerzeit endet in {RestMinuten} Minuten. Bitte speichere deine Arbeit.",
    "expired": "Deine Computerzeit für heute ist aufgebraucht. Bis morgen!",
    "denied": "Deine Computerzeit für heute ist bereits aufgebraucht. Du wirst jetzt abgemeldet.",
}


def validate_plan(plan: tuple[DayLimit, ...] | list[DayLimit]) -> tuple[DayLimit, ...]:
    if len(plan) != 7:
        raise ConfigError("Der Wochenplan braucht genau sieben Tage.")
    for day in plan:
        day.validate()
    return tuple(plan)


# ---------- Zeitintervalle ----------

Interval = tuple[float, float]


def merge_intervals(intervals: list[Interval] | tuple[Interval, ...]) -> list[Interval]:
    """Führt überlappende Intervalle zusammen. Gleichzeitige Sitzungen zählen dadurch nur einmal."""
    merged: list[Interval] = []
    for start, end in sorted(i for i in intervals if i[1] > i[0]):
        if merged and start <= merged[-1][1]:
            merged[-1] = (merged[-1][0], max(merged[-1][1], end))
        else:
            merged.append((start, end))
    return merged


def used_seconds(intervals: list[Interval], window_start: float, window_end: float) -> float:
    """Nutzungszeit innerhalb eines Zeitfensters. Intervalle werden auf das Fenster zugeschnitten."""
    clipped = [(max(s, window_start), min(e, window_end)) for s, e in intervals]
    return sum(e - s for s, e in merge_intervals(clipped))


def day_window(day: dt.date) -> tuple[float, float]:
    """Start und Ende eines lokalen Kalendertags als Unix-Zeitstempel (Systemzeitzone inkl. Sommer-/Winterzeit)."""
    start = dt.datetime.combine(day, dt.time()).astimezone().timestamp()
    end = dt.datetime.combine(day + dt.timedelta(days=1), dt.time()).astimezone().timestamp()
    return start, end


def day_of(timestamp: float) -> dt.date:
    return dt.datetime.fromtimestamp(timestamp).date()


# ---------- Budget ----------

@dataclass(frozen=True)
class BudgetStatus:
    unlimited: bool
    limit_s: float
    extension_s: float
    used_s: float

    @property
    def total_s(self) -> float:
        return self.limit_s + self.extension_s

    @property
    def remaining_s(self) -> float:
        if self.unlimited:
            return math.inf
        return max(0.0, self.total_s - self.used_s)

    @property
    def exhausted(self) -> bool:
        return not self.unlimited and self.total_s - self.used_s <= 0


def evaluate_budget(day_limit: DayLimit, extension_minutes: int, used_s: float) -> BudgetStatus:
    if used_s < 0 or extension_minutes < 0:
        raise ValueError("Verbrauch und Verlängerung dürfen nicht negativ sein.")
    if not day_limit.enabled:
        return BudgetStatus(True, 0.0, extension_minutes * 60.0, used_s)
    return BudgetStatus(False, day_limit.minutes * 60.0, extension_minutes * 60.0, used_s)


def next_warning(remaining_s: float, shown: set[int], thresholds: list[int] | tuple[int, ...]) -> int | None:
    """Liefert die dringendste noch nicht gezeigte Schwelle. Weniger dringende gelten danach als erledigt."""
    candidates = [t for t in thresholds if remaining_s <= t * 60 and t not in shown]
    if not candidates:
        return None
    chosen = min(candidates)
    shown.update(t for t in thresholds if t >= chosen)
    return chosen


def render_text(template: str, remaining_s: float) -> str:
    minutes = 0 if math.isinf(remaining_s) else max(0, math.ceil(remaining_s / 60))
    return template.replace("{RestMinuten}", str(minutes))


# ---------- Passwort ----------

def hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, PBKDF2_ITERATIONS)
    return f"pbkdf2_sha256${PBKDF2_ITERATIONS}${salt.hex()}${digest.hex()}"


def verify_password(password: str, stored: str) -> bool:
    try:
        algorithm, iterations, salt_hex, digest_hex = stored.split("$")
        if algorithm != "pbkdf2_sha256":
            return False
        expected = bytes.fromhex(digest_hex)
        actual = hashlib.pbkdf2_hmac(
            "sha256", password.encode("utf-8"), bytes.fromhex(salt_hex), int(iterations), len(expected)
        )
    except ValueError:
        return False
    return hmac.compare_digest(actual, expected)


def password_problem(password: str) -> str | None:
    """None bei ausreichend starkem Passwort, sonst eine deutsche Meldung."""
    if len(password) < MIN_PASSWORD_LENGTH:
        return f"Das Passwort muss mindestens {MIN_PASSWORD_LENGTH} Zeichen lang sein."
    classes = sum([
        any(c.islower() for c in password),
        any(c.isupper() for c in password),
        any(c.isdigit() for c in password),
        any(not c.isalnum() for c in password),
    ])
    if classes < 3:
        return "Das Passwort braucht drei von vier Arten: Kleinbuchstaben, Großbuchstaben, Ziffern, Sonderzeichen."
    return None
