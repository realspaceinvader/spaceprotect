"""Durchsetzung: erfasst die Nutzungszeit des Kinderkontos, zeigt Warnungen und meldet bei Budgetende ab."""

from __future__ import annotations

import datetime as dt
import logging
import time
import traceback
from typing import Callable

from . import core
from .core import BudgetStatus, day_of, day_window, evaluate_budget, used_seconds
from .storage import Store


def day_status(store: Store, sid: str, day: dt.date) -> BudgetStatus:
    """Budgetstand eines Tags für die Anzeige (inkl. laufender Sitzung bis zum letzten Checkpoint)."""
    start, end = day_window(day)
    used = used_seconds(store.all_intervals(sid, start, end), start, end)
    extension = store.extension_minutes(sid, day.isoformat())
    return evaluate_budget(store.plan()[day.weekday()], extension, used)


class Enforcer:
    """
    Wird alle POLL_SECONDS über tick() aufgerufen.
    Laufende Zeit wird mit der Monotonuhr addiert; Lücken über MAX_GAP_SECONDS werden nicht gezählt.
    """

    def __init__(
        self,
        store: Store,
        child_sid: str,
        list_sessions: Callable[[str], list[int]],
        logoff: Callable[[int], bool],
        message: Callable[[int, str], bool],
        wall: Callable[[], float] = time.time,
        mono: Callable[[], float] = time.monotonic,
    ) -> None:
        self.store = store
        self.sid = child_sid
        self._list_sessions = list_sessions
        self._logoff = logoff
        self._message = message
        self._wall = wall
        self._mono = mono

        self._was_on = False
        self._fresh = False
        self._open_id: int | None = None
        self._start = 0.0
        self._running = 0.0
        self._last_checkpoint = 0.0
        self._last_mono: float | None = None
        self._last_wall: float | None = None
        self._shown: set[int] = set()
        self._last_error_audit = -1e9
        self._reset_logoff()

    def _reset_logoff(self) -> None:
        self._logoff_due: float | None = None
        self._next_attempt = 0.0
        self._attempts = 0
        self._abandoned = False

    def tick(self) -> None:
        wall = self._wall()
        mono = self._mono()
        sessions = self._list_sessions(self.sid)
        on = bool(sessions)

        if self._last_mono is not None and self._last_wall is not None:
            delta = mono - self._last_mono
            wall_delta = wall - self._last_wall
            if abs(wall_delta - delta) > core.CLOCK_TOLERANCE_SECONDS:
                self.store.audit("Systemzeit", f"Auffällige Systemzeitänderung oder Ruhezustand "
                                               f"(Wanduhr {wall_delta:.0f} s, Monotonuhr {delta:.0f} s). "
                                               "Zählung folgt der Monotonuhr.")
            if self._was_on and self._open_id is not None:
                if delta <= core.MAX_GAP_SECONDS:
                    self._running += delta
                else:
                    self.store.audit("Unterbrechung", f"Lücke von {delta:.0f} s (Schlaf oder Hänger). "
                                                      "Diese Zeit wird nicht gezählt.")

        try:
            if on and not self._was_on:
                self._login(wall, mono)
            elif not on and self._was_on:
                self._logout()

            if on:
                try:
                    self._enforce(day_of(wall), sessions, wall, mono)
                except Exception as error:  # noqa: BLE001 - die Zeiterfassung darf nie davon abhängen
                    self._report_error(error, mono)
                finally:
                    self._fresh = False
        finally:
            # Zustand immer fortschreiben, sonst würde die Sitzung bei jedem Durchlauf neu beginnen.
            self._was_on = on
            self._last_mono = mono
            self._last_wall = wall

        if self._open_id is not None and mono - self._last_checkpoint >= core.CHECKPOINT_SECONDS:
            self.store.checkpoint(self._open_id, self._start + self._running)
            self._last_checkpoint = mono

    def shutdown(self) -> None:
        if self._open_id is not None:
            self.store.close_interval(self._open_id, self._start + self._running)
            self._open_id = None
            self.store.audit("Dienst", "Dienst beendet. Laufende Nutzungszeit wurde gespeichert.")

    def _report_error(self, error: Exception, mono: float) -> None:
        """Protokolliert Fehler der Durchsetzung (höchstens einmal pro Minute im Ereignisprotokoll)."""
        logging.getLogger("spaceprotect").error("Fehler bei der Durchsetzung:\n%s", traceback.format_exc())
        if mono - self._last_error_audit >= 60.0:
            self._last_error_audit = mono
            self.store.audit("Fehler", f"Fehler bei der Durchsetzung: {type(error).__name__}: {error}")

    def _notify(self, session_id: int, text: str) -> None:
        """Zeigt einen Hinweis. Scheitert das, wird weiter durchgesetzt (Abmeldung hängt nicht davon ab)."""
        try:
            self._message(session_id, text)
        except Exception as error:  # noqa: BLE001
            self._report_error(error, self._mono())

    def _login(self, wall: float, mono: float) -> None:
        if self._open_id is not None:  # defensiv: nie zwei offene Intervalle gleichzeitig
            self.store.close_interval(self._open_id, self._start + self._running)
        self._start = wall
        self._running = 0.0
        self._open_id = self.store.open_interval(self.sid, wall)
        self._last_checkpoint = mono
        self._shown = set()
        self._reset_logoff()
        self._fresh = True
        self.store.audit("Anmeldung", "Anmeldung des Kinderkontos erkannt.")

    def _logout(self) -> None:
        if self._open_id is not None:
            self.store.close_interval(self._open_id, self._start + self._running)
            self._open_id = None
        self._running = 0.0
        self._reset_logoff()
        self.store.audit("Abmeldung", "Abmeldung des Kinderkontos erkannt.")

    def _status(self, day: dt.date, wall: float) -> BudgetStatus:
        start, end = day_window(day)
        intervals = self.store.closed_intervals(self.sid, start, end)
        if self._open_id is not None:
            intervals.append((self._start, self._start + self._running))
        used = used_seconds(intervals, start, end)
        extension = self.store.extension_minutes(self.sid, day.isoformat())
        return evaluate_budget(self.store.plan()[day.weekday()], extension, used)

    def _enforce(self, day: dt.date, sessions: list[int], wall: float, mono: float) -> None:
        status = self._status(day, wall)
        if status.unlimited:
            return
        if not status.exhausted:
            self._reset_logoff()
            self._warn(status, sessions)
            return

        if self._logoff_due is None:
            texts = self.store.texts()
            self._logoff_due = mono + (0.0 if self._fresh else core.LOGOFF_GRACE_SECONDS)
            self._next_attempt = self._logoff_due
            text = texts["denied"] if self._fresh else texts["expired"]
            for session_id in sessions:
                self._notify(session_id, text)
            self.store.audit("Budget", "Erneute Anmeldung bei aufgebrauchtem Tagesbudget. Abmeldung eingeleitet."
                             if self._fresh else "Tagesbudget aufgebraucht. Abmeldung eingeleitet.")

        if self._abandoned or mono < self._logoff_due or mono < self._next_attempt:
            return
        if self._attempts >= core.MAX_LOGOFF_ATTEMPTS:
            self._abandoned = True
            self.store.audit("Fehler", f"Abmeldung nach {core.MAX_LOGOFF_ATTEMPTS} Versuchen fehlgeschlagen. "
                                       "Keine weiteren Versuche, bis die Sitzung endet.")
            return

        self._attempts += 1
        self._next_attempt = mono + core.LOGOFF_RETRY_SECONDS
        for session_id in sessions:
            try:
                ok = self._logoff(session_id)
            except Exception as error:  # noqa: BLE001
                self._report_error(error, mono)
                ok = False
            self.store.audit("Abmeldung" if ok else "Fehler",
                             f"Automatische Abmeldung von Sitzung {session_id} "
                             f"{'angefordert' if ok else 'fehlgeschlagen'} (Versuch {self._attempts}).")

    def _warn(self, status: BudgetStatus, sessions: list[int]) -> None:
        texts = self.store.texts()
        thresholds = texts["warn_minutes"]
        threshold = core.next_warning(status.remaining_s, self._shown, thresholds)
        if threshold is None:
            return
        template = texts["final"] if threshold == min(thresholds) else texts["warn"]
        text = core.render_text(template, status.remaining_s)
        for session_id in sessions:
            self._notify(session_id, text)
        self.store.audit("Warnung", f"Warnung ({threshold} Min.) angezeigt: {text}")
