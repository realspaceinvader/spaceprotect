"""Verwaltungsoberfläche (CustomTkinter, dunkles Design, ☰-Menü)."""

from __future__ import annotations

import ctypes
import datetime as dt
import os
import queue
import sqlite3
import sys
import time
import tkinter as tk
import traceback
import uuid
import webbrowser
from tkinter import messagebox

import customtkinter as ctk
from PIL import ImageTk

from . import core, icons, installer, paths, winapi
from .core import ConfigError, DayLimit
from .engine import day_status
from .i18n import translate
from .storage import Store

REFRESH_MS = 5000
SUPPORT_URL = "https://buymeacoffee.com/spaceinvader"
WEBSITE_URL = "https://spaceinvader.at"


def _logo_image():
    """Logo für Info-Fenster; liegt in der EXE oder im Projektordner."""
    from PIL import Image

    return Image.open(paths.resource_path(os.path.join("assets", "spaceprotect-logo.png"))).convert("RGBA")
ACCENT = "#5b8dff"


def menu_palette() -> dict[str, str]:
    """Menüfarben passend zum aktuellen Theme (hell oder dunkel)."""
    if ctk.get_appearance_mode() == "Light":
        return {"bg": "#ffffff", "fg": "#1b1b1b", "active": "#3b78c4", "active_fg": "#ffffff"}
    return {"bg": "#25282e", "fg": "#f2f2f2", "active": "#3b78c4", "active_fg": "#ffffff"}


class LoginDialog(ctk.CTkToplevel):
    """Passwortabfrage. Beim ersten Start wird ein neues Passwort festgelegt."""

    def __init__(self, master: ctk.CTk, store: Store, t) -> None:
        super().__init__(master)
        self.store = store
        self.t = t
        self.authenticated = False
        self.failures = 0
        self.stored = store.get("admin_password")
        self.title(t("pw_set_title" if self.stored is None else "pw_login_title"))
        self.geometry("380x300")
        self.resizable(False, False)
        self.protocol("WM_DELETE_WINDOW", self._cancel)
        self.transient(master)
        self.grab_set()

        ctk.CTkLabel(self, text=t("app_title"), font=ctk.CTkFont(size=20, weight="bold")).pack(pady=(24, 12))
        self.entry = ctk.CTkEntry(self, show="•", width=280, placeholder_text=t("pw_enter"))
        self.entry.pack(pady=6)
        self.entry2 = None
        if self.stored is None:
            self.entry2 = ctk.CTkEntry(self, show="•", width=280, placeholder_text=t("pw_repeat"))
            self.entry2.pack(pady=6)
            self.entry.configure(placeholder_text=t("pw_new"))
        self.message = ctk.CTkLabel(self, text="", text_color="#ff6b6b")
        self.message.pack(pady=4)
        self.button = ctk.CTkButton(self, text=t("pw_login" if self.stored else "save"), width=280,
                                    fg_color=ACCENT, command=self._submit)
        self.button.pack(pady=8)
        self.entry.focus_set()
        self.bind("<Return>", lambda _e: self._submit())

    def _submit(self) -> None:
        password = self.entry.get()
        if self.stored is None:
            problem = core.password_problem(password)
            if problem:
                self.message.configure(text=problem)
                return
            if password != (self.entry2.get() if self.entry2 else ""):
                self.message.configure(text=self.t("pw_mismatch"))
                return
            self.store.set("admin_password", core.hash_password(password))
            self.store.audit("Verwaltung", "Verwaltungspasswort festgelegt.")
            self.authenticated = True
            self.destroy()
            return

        if core.verify_password(password, self.stored):
            self.store.audit("Verwaltung", "Verwaltung entsperrt.")
            self.authenticated = True
            self.destroy()
            return

        self.failures += 1
        self.store.audit("Verwaltung", f"Falsches Passwort ({self.failures}).")
        if self.failures >= 5:
            self.message.configure(text=self.t("pw_too_many"))
            self.after(3000, self._cancel)
            return
        self.message.configure(text=self.t("pw_wrong"))
        self.entry.delete(0, "end")
        # Verzögerung gegen Massenversuche: 2, 4, 8, 16 Sekunden.
        self.button.configure(state="disabled")
        self.after(min(16, 2 ** self.failures) * 1000, lambda: self.button.configure(state="normal"))

    def _cancel(self) -> None:
        self.destroy()


def open_store() -> Store:
    """Öffnet die Datenbank. Schlägt das fehl, werden die Datenrechte repariert und ein zweiter Versuch gemacht."""
    try:
        return Store(paths.database_path())
    except sqlite3.Error:
        report_error("Datenbank konnte nicht geöffnet werden, Datenrechte werden repariert")
        installer.repair_data_access()
        return Store(paths.database_path())


class App(ctk.CTk):
    def __init__(self) -> None:
        super().__init__()
        self.store = open_store()
        self.lang = self.store.get("ui_lang", "de")
        ctk.set_appearance_mode(self.store.get("ui_theme", "dark"))
        ctk.set_default_color_theme("blue")

        self.title("Spaceprotect")
        self.geometry("1000x700")
        self.minsize(860, 620)
        self._menu_var_theme = tk.StringVar(value=self.store.get("ui_theme", "dark"))
        self._menu_var_lang = tk.StringVar(value=self.lang)
        self._refresh_job: str | None = None
        self._accounts: dict[str, str] = {}

        # Während der Anmeldung unsichtbar (transparent), NICHT withdraw(): CustomTkinter blendet das Fenster
        # intern aus und ein und würde ein vorher zurückgezogenes Fenster dauerhaft versteckt lassen.
        self.attributes("-alpha", 0.0)
        login = LoginDialog(self, self.store, self.t)
        self.wait_window(login)
        if not login.authenticated:
            self.store.close()
            self.cancelled = True
            self.destroy()
            return
        self.cancelled = False
        self.tray = None  # Das Hinweis-Symbol zeigt der separate Agent (--agent), nicht die Verwaltung.
        self.attributes("-alpha", 1.0)
        self._build()
        self.protocol("WM_DELETE_WINDOW", self._close)

    # ---------- Grundgerüst ----------

    def t(self, key: str, **values: str) -> str:
        return translate(self.lang, key, **values)

    def report_callback_exception(self, exc, val, tb) -> None:
        """Fehler in Schaltflächen und Timern werden protokolliert statt still verschluckt."""
        report_error("Fehler in der Oberfläche", (exc, val, tb))
        try:
            messagebox.showerror("Spaceprotect", self.t("error_callback"), parent=self)
        except tk.TclError:
            pass

    def _request_quit(self) -> None:
        """Schließt die Verwaltung. Das Passwort wurde beim Öffnen bereits abgefragt."""
        self._close()

    def _build(self) -> None:
        for widget in self.winfo_children():
            widget.destroy()
        self._cancel_refresh()
        self._menu = self._build_menu()

        header = ctk.CTkFrame(self, fg_color="transparent")
        header.pack(fill="x", padx=24, pady=(18, 6))
        bars = icons.hamburger((31, 35, 41, 255))
        bars_light = icons.hamburger((242, 242, 242, 255))
        self._hamburger_img = ctk.CTkImage(light_image=bars, dark_image=bars_light, size=(22, 22))
        ctk.CTkButton(header, text="", image=self._hamburger_img, width=44, height=40, fg_color="transparent",
                      hover_color=("gray80", "gray25"), command=self._open_menu).pack(side="left")
        ctk.CTkLabel(header, text=self.t("app_title"),
                     font=ctk.CTkFont(size=24, weight="bold")).pack(side="left", padx=14)
        ctk.CTkButton(header, text=self.t("uninstall"), width=150, fg_color="#c0392b", hover_color="#962d22",
                      command=self._uninstall).pack(side="right", padx=(8, 0))
        self.status_pill = ctk.CTkLabel(header, text="", font=ctk.CTkFont(size=13))
        self.status_pill.pack(side="right", padx=12)

        self.tabs = ctk.CTkTabview(self, corner_radius=14)
        self.tabs.pack(fill="both", expand=True, padx=24, pady=(6, 20))
        for key in ("tab_overview", "tab_plan", "tab_messages", "tab_log", "tab_settings"):
            self.tabs.add(self.t(key))

        self._build_overview(self.tabs.tab(self.t("tab_overview")))
        self._build_plan(self.tabs.tab(self.t("tab_plan")))
        self._build_messages(self.tabs.tab(self.t("tab_messages")))
        self._build_log(self.tabs.tab(self.t("tab_log")))
        self._build_settings(self.tabs.tab(self.t("tab_settings")))

        self._refresh()

    def _menu_icons(self) -> dict:
        """Menü-Symbole als Tk-Bilder. Referenzen bleiben am Fenster, sonst verschwinden sie."""
        if getattr(self, "_icons", None) is None:
            self._icons = {name: ImageTk.PhotoImage(image) for name, image in icons.menu_icons(ctk.get_appearance_mode()).items()}
        return self._icons

    def _build_menu(self) -> tk.Menu:
        palette = menu_palette()
        symbols = self._menu_icons()

        def make(parent: tk.Misc) -> tk.Menu:
            return tk.Menu(parent, tearoff=0, bg=palette["bg"], fg=palette["fg"],
                           activebackground=palette["active"], activeforeground=palette["active_fg"],
                           font=("Segoe UI", 10), bd=1, relief="solid")

        menu = make(self)
        theme_menu = make(menu)
        lang_menu = make(menu)
        theme_menu.add_radiobutton(label=self.t("theme_light"), image=symbols["sun"], compound="left",
                                   variable=self._menu_var_theme, value="light",
                                   command=lambda: self._set_theme("light"))
        theme_menu.add_radiobutton(label=self.t("theme_dark"), image=symbols["moon"], compound="left",
                                   variable=self._menu_var_theme, value="dark",
                                   command=lambda: self._set_theme("dark"))
        lang_menu.add_radiobutton(label=self.t("lang_de"), variable=self._menu_var_lang,
                                  value="de", command=lambda: self._set_language("de"))
        lang_menu.add_radiobutton(label=self.t("lang_en"), variable=self._menu_var_lang,
                                  value="en", command=lambda: self._set_language("en"))
        menu.add_cascade(label=self.t("menu_theme"), menu=theme_menu)
        menu.add_cascade(label=self.t("menu_language"), menu=lang_menu)
        menu.add_separator()
        menu.add_command(label=self.t("menu_info"), image=symbols["info"], compound="left", command=self._show_info)
        menu.add_command(label=self.t("menu_close"), image=symbols["close"], compound="left", command=self._request_quit)
        return menu

    def _open_menu(self) -> None:
        x = self.winfo_rootx() + 24
        y = self.winfo_rooty() + 70
        self._menu.tk_popup(x, y)

    def _set_theme(self, theme: str) -> None:
        ctk.set_appearance_mode(theme)
        self.store.set("ui_theme", theme)
        self._icons = None
        self._menu = self._build_menu()

    def _set_language(self, lang: str) -> None:
        self.lang = lang
        self.store.set("ui_lang", lang)
        self._build()

    def _show_info(self) -> None:
        dialog = ctk.CTkToplevel(self)
        dialog.title(self.t("menu_info"))
        dialog.geometry("400x520")
        dialog.resizable(False, False)
        dialog.transient(self)
        dialog.grab_set()

        try:
            logo = ctk.CTkImage(light_image=_logo_image(), dark_image=_logo_image(), size=(96, 96))
            ctk.CTkLabel(dialog, text="", image=logo).pack(pady=(28, 6))
        except Exception:  # noqa: BLE001 - ohne Logo bleibt der Text vollständig sichtbar
            report_error("Logo im Info-Fenster konnte nicht geladen werden")
        ctk.CTkLabel(dialog, text=self.t("app_title"), font=ctk.CTkFont(size=22, weight="bold")).pack()
        ctk.CTkLabel(dialog, text=f"{self.t('settings_version')} {core.__version__}",
                     text_color=("gray35", "gray70")).pack(pady=(2, 10))
        ctk.CTkLabel(dialog, text=self.t("info_text"), wraplength=320, justify="center").pack(pady=(0, 14))
        ctk.CTkButton(dialog, text=WEBSITE_URL, fg_color="transparent", text_color=("#2f6fd6", "#7aa7ff"),
                      hover_color=("gray85", "gray25"), command=lambda: webbrowser.open(WEBSITE_URL)).pack(pady=2)
        ctk.CTkButton(dialog, text=self.t("support"), fg_color=ACCENT, width=260,
                      command=lambda: webbrowser.open(SUPPORT_URL)).pack(pady=(14, 6))
        ctk.CTkButton(dialog, text=self.t("close"), fg_color="#343842", hover_color="#454a55", width=260,
                      command=dialog.destroy).pack(pady=6)

    def _close(self) -> None:
        self._cancel_refresh()
        if self.tray is not None:
            self.tray.stop()
        self.store.close()
        self.destroy()

    def _cancel_refresh(self) -> None:
        if self._refresh_job is not None:
            try:
                self.after_cancel(self._refresh_job)
            except tk.TclError:
                pass
            self._refresh_job = None

    def _card(self, parent, title: str) -> ctk.CTkFrame:
        frame = ctk.CTkFrame(parent, corner_radius=14)
        frame.pack(fill="x", padx=16, pady=8)
        ctk.CTkLabel(frame, text=title, font=ctk.CTkFont(size=15, weight="bold")).pack(anchor="w", padx=16, pady=(12, 4))
        return frame

    # ---------- Übersicht ----------

    def _build_overview(self, page) -> None:
        account = self._card(page, self.t("child_account"))
        row = ctk.CTkFrame(account, fg_color="transparent")
        row.pack(fill="x", padx=16, pady=(0, 14))
        try:
            self._accounts = {name: sid for sid, name in winapi.standard_accounts()}
        except Exception:  # noqa: BLE001 - Kontenliste darf die Oberfläche nicht abbrechen
            self._accounts = {}
            report_error("Kontenliste konnte nicht gelesen werden")
        names = list(self._accounts) or [self.t("no_accounts")]
        current = self.store.child()
        self.account_var = ctk.StringVar(value=current[1] if current and current[1] in names else names[0])
        ctk.CTkOptionMenu(row, values=names, variable=self.account_var, width=260).pack(side="left")
        ctk.CTkButton(row, text=self.t("apply_account"), width=180, fg_color=ACCENT,
                      command=self._apply_account).pack(side="left", padx=12)

        stats = self._card(page, self.t("tab_overview"))
        self.no_child_label = ctk.CTkLabel(stats, text=self.t("no_child"), wraplength=700, justify="left")
        self.no_child_label.pack(anchor="w", padx=16, pady=(0, 10))
        grid = ctk.CTkFrame(stats, fg_color="transparent")
        grid.pack(fill="x", padx=16, pady=(0, 6))
        self.stat_values: dict[str, ctk.CTkLabel] = {}
        for column, key in enumerate(("limit", "extension", "used", "remaining")):
            box = ctk.CTkFrame(grid, corner_radius=12)
            box.grid(row=0, column=column, padx=6, pady=4, sticky="nsew")
            grid.grid_columnconfigure(column, weight=1)
            ctk.CTkLabel(box, text=self.t(key), text_color=("gray35", "gray70")).pack(pady=(10, 0))
            value = ctk.CTkLabel(box, text="–", font=ctk.CTkFont(size=20, weight="bold"))
            value.pack(pady=(2, 10))
            self.stat_values[key] = value
        self.progress = ctk.CTkProgressBar(stats, progress_color=ACCENT)
        self.progress.pack(fill="x", padx=16, pady=(8, 4))
        self.progress.set(0)
        self.budget_text = ctk.CTkLabel(stats, text="", text_color=("gray35", "gray70"))
        self.budget_text.pack(anchor="w", padx=16, pady=(0, 12))

        service = self._card(page, self.t("service"))
        srow = ctk.CTkFrame(service, fg_color="transparent")
        srow.pack(fill="x", padx=16, pady=(0, 14))
        self.service_label = ctk.CTkLabel(srow, text="", font=ctk.CTkFont(size=14))
        self.service_label.pack(side="left")
        self.service_buttons = ctk.CTkFrame(srow, fg_color="transparent")
        self.service_buttons.pack(side="right")

        extend = self._card(page, self.t("extend_title"))
        erow = ctk.CTkFrame(extend, fg_color="transparent")
        erow.pack(fill="x", padx=16, pady=(0, 14))
        for minutes in (15, 30, 60):
            ctk.CTkButton(erow, text=f"+{minutes}", width=90, fg_color=ACCENT,
                          command=lambda m=minutes: self._extend(m)).pack(side="left", padx=(0, 8))
        self.custom_minutes = ctk.CTkEntry(erow, width=110, placeholder_text=self.t("minutes"))
        self.custom_minutes.pack(side="left", padx=(16, 8))
        ctk.CTkButton(erow, text=self.t("extend_book"), width=120,
                      command=lambda: self._extend(self.custom_minutes.get())).pack(side="left")

    def _apply_account(self) -> None:
        name = self.account_var.get()
        sid = self._accounts.get(name)
        if sid is None:
            return
        if not messagebox.askyesno("Spaceprotect", self.t("confirm_account", name=name)):
            return
        self.store.set_child(sid, name)
        self.store.audit("Konfiguration", f"Kinderkonto geändert auf \"{name}\".")
        self._refresh()

    def _extend(self, minutes_value) -> None:
        child = self.store.child()
        if child is None:
            return
        try:
            minutes = int(minutes_value)
            if not 1 <= minutes <= 1440:
                raise ValueError
        except (TypeError, ValueError):
            messagebox.showerror(self.t("error"), self.t("invalid"))
            return
        today = dt.date.today().isoformat()
        booked = self.store.add_extension(child[0], today, minutes, uuid.uuid4().hex)
        if booked:
            self.store.audit("Verlängerung", f"+{minutes} Min. für {today} vergeben.")
            messagebox.showinfo("Spaceprotect", self.t("extend_done"))
        else:
            messagebox.showinfo("Spaceprotect", self.t("extend_dup"))
        self._refresh()

    def _refresh(self) -> None:
        self._cancel_refresh()
        self._refresh_service()
        child = self.store.child()
        if child is None:
            self.no_child_label.configure(text=self.t("no_child"))
            self._set_stats_placeholder()
        else:
            self.no_child_label.configure(text=f"{self.t('child_account')}: {child[1]}")
            status = day_status(self.store, child[0], dt.date.today())
            self._fill_stats(status)
        self._refresh_job = self.after(REFRESH_MS, self._refresh)

    def _set_stats_placeholder(self) -> None:
        for value in self.stat_values.values():
            value.configure(text="–")
        self.progress.set(0)
        self.budget_text.configure(text="")

    def _fill_stats(self, status: core.BudgetStatus) -> None:
        def fmt(seconds: float) -> str:
            if seconds == float("inf"):
                return self.t("unlimited")
            total = int(round(seconds / 60))
            return f"{total // 60:02d}:{total % 60:02d} h"

        self.stat_values["limit"].configure(text=fmt(status.limit_s) if not status.unlimited else self.t("unlimited"))
        self.stat_values["extension"].configure(text=fmt(status.extension_s))
        self.stat_values["used"].configure(text=fmt(status.used_s))
        self.stat_values["remaining"].configure(text=fmt(status.remaining_s))
        if status.unlimited or status.total_s <= 0:
            self.progress.set(1 if not status.unlimited else 0)
        else:
            self.progress.set(min(1.0, status.used_s / status.total_s))
        self.budget_text.configure(text=self.t("time_up") if status.exhausted else self.t("time_left")
                                   if not status.unlimited else "")

    def _refresh_service(self) -> None:
        state = installer.service_state()
        labels = {"running": "svc_running", "stopped": "svc_stopped", "missing": "svc_missing", "pending": "svc_pending"}
        self.service_label.configure(text=f"{self.t('service')}: {self.t(labels[state])}")
        if self.tray is not None:
            self.tray.set_title(f"Spaceprotect – {self.t('service')}: {self.t(labels[state])}")
        self.status_pill.configure(text=f"● {self.t(labels[state])}",
                                   text_color="#3ddc84" if state == "running" else "#ffb020")
        for widget in self.service_buttons.winfo_children():
            widget.destroy()
        if state == "missing":
            ctk.CTkButton(self.service_buttons, text=self.t("install"), width=140, fg_color=ACCENT,
                          command=self._install).pack(side="left")
        else:
            ctk.CTkButton(self.service_buttons, text=self.t("repair"), width=120, fg_color="#343842",
                          hover_color="#454a55", command=self._install).pack(side="left", padx=4)
            if state == "running":
                ctk.CTkButton(self.service_buttons, text=self.t("stop"), width=110,
                              command=self._stop_service).pack(side="left", padx=4)
            else:
                ctk.CTkButton(self.service_buttons, text=self.t("start"), width=110, fg_color=ACCENT,
                              command=self._start_service).pack(side="left", padx=4)

    def _install(self) -> None:
        self._run_privileged(lambda: installer.install(), self.t("installed_ok"))

    def _start_service(self) -> None:
        installer.start_service()
        self.service_label.configure(text=f"{self.t('service')}: {self.t('svc_pending')}")
        self.after(10000, self._check_service_started)

    def _check_service_started(self) -> None:
        if installer.service_state() != "running":
            messagebox.showerror(self.t("error"), installer.service_failure_text())
        self._refresh_service()

    def _stop_service(self) -> None:
        installer.stop_service()
        self.after(1000, self._refresh_service)

    def _run_privileged(self, action, success_text: str) -> None:
        try:
            action()
        except (installer.InstallError, OSError) as error:
            messagebox.showerror(self.t("error"), str(error))
            return
        messagebox.showinfo("Spaceprotect", success_text)
        self._refresh()

    # ---------- Wochenplan ----------

    def _build_plan(self, page) -> None:
        card = self._card(page, self.t("tab_plan"))
        ctk.CTkLabel(card, text=self.t("plan_hint"), text_color=("gray35", "gray70"), wraplength=820,
                     justify="left").pack(anchor="w", padx=16, pady=(0, 10))
        self.plan_rows: list[tuple[ctk.CTkSwitch, ctk.CTkEntry, ctk.CTkEntry]] = []
        header = ctk.CTkFrame(card, fg_color="transparent")
        header.pack(fill="x", padx=16)
        for text, width in ((self.t("day"), 160), (self.t("active"), 120), (self.t("hours"), 120), (self.t("minutes"), 120)):
            ctk.CTkLabel(header, text=text, width=width, anchor="w", font=ctk.CTkFont(weight="bold")).pack(side="left")
        plan = self.store.plan()
        for index, day_name in enumerate(self.t("days").split(",")):
            row = ctk.CTkFrame(card, fg_color="transparent")
            row.pack(fill="x", padx=16, pady=3)
            ctk.CTkLabel(row, text=day_name, width=160, anchor="w").pack(side="left")
            switch = ctk.CTkSwitch(row, text="", width=120)
            if plan[index].enabled:
                switch.select()
            switch.pack(side="left")
            hours = ctk.CTkEntry(row, width=110)
            hours.insert(0, str(plan[index].minutes // 60))
            hours.pack(side="left", padx=4)
            minutes = ctk.CTkEntry(row, width=110)
            minutes.insert(0, str(plan[index].minutes % 60))
            minutes.pack(side="left", padx=4)
            self.plan_rows.append((switch, hours, minutes))
        ctk.CTkButton(card, text=self.t("save"), width=200, fg_color=ACCENT, command=self._save_plan).pack(
            anchor="w", padx=16, pady=14)

    def _save_plan(self) -> None:
        try:
            days = []
            for switch, hours, minutes in self.plan_rows:
                h = int(hours.get().strip() or 0)
                m = int(minutes.get().strip() or 0)
                if not (0 <= h <= 24 and 0 <= m <= 59) or h * 60 + m > core.MAX_MINUTES:
                    raise ConfigError("Stunden 0–24, Minuten 0–59, insgesamt höchstens 24:00.")
                days.append(DayLimit(bool(switch.get()), h * 60 + m))
            self.store.save_plan(tuple(days))
            self.store.audit("Konfiguration", "Wochenplan geändert.")
        except (ValueError, ConfigError) as error:
            messagebox.showerror(self.t("invalid"), str(error) if isinstance(error, ConfigError) else self.t("invalid"))
            return
        messagebox.showinfo("Spaceprotect", self.t("saved"))
        self._refresh()

    # ---------- Meldungen ----------

    def _build_messages(self, page) -> None:
        card = self._card(page, self.t("tab_messages"))
        ctk.CTkLabel(card, text=self.t("msg_hint"), text_color=("gray35", "gray70")).pack(anchor="w", padx=16, pady=(0, 8))
        texts = self.store.texts()
        self.text_entries: dict[str, ctk.CTkEntry] = {}
        fields = (
            ("warn_minutes", self.t("warn_minutes"), ",".join(str(m) for m in texts["warn_minutes"])),
            ("warn", self.t("msg_warn"), texts["warn"]),
            ("final", self.t("msg_final"), texts["final"]),
            ("expired", self.t("msg_expired"), texts["expired"]),
            ("denied", self.t("msg_denied"), texts["denied"]),
        )
        for key, label, value in fields:
            ctk.CTkLabel(card, text=label, anchor="w").pack(fill="x", padx=16, pady=(8, 0))
            entry = ctk.CTkEntry(card, width=760)
            entry.insert(0, value)
            entry.pack(anchor="w", padx=16, pady=(2, 0))
            self.text_entries[key] = entry
        ctk.CTkButton(card, text=self.t("save"), width=200, fg_color=ACCENT, command=self._save_texts).pack(
            anchor="w", padx=16, pady=14)

    def _save_texts(self) -> None:
        try:
            minutes = [int(part) for part in self.text_entries["warn_minutes"].get().split(",") if part.strip()]
            if not minutes or any(not 1 <= m <= 1440 for m in minutes):
                raise ValueError
        except ValueError:
            messagebox.showerror(self.t("invalid"), self.t("warn_minutes"))
            return
        self.store.set_json("texts", {
            "warn_minutes": sorted(set(minutes), reverse=True),
            "warn": self.text_entries["warn"].get(),
            "final": self.text_entries["final"].get(),
            "expired": self.text_entries["expired"].get(),
            "denied": self.text_entries["denied"].get(),
        })
        self.store.audit("Konfiguration", "Meldungstexte geändert.")
        messagebox.showinfo("Spaceprotect", self.t("saved"))

    # ---------- Protokoll ----------

    def _build_log(self, page) -> None:
        card = self._card(page, self.t("tab_log"))
        bar = ctk.CTkFrame(card, fg_color="transparent")
        bar.pack(fill="x", padx=16, pady=(0, 8))
        self.log_range = ctk.CTkSegmentedButton(bar, values=[self.t("log_7"), self.t("log_30")],
                                                command=lambda _v: self._fill_log())
        self.log_range.set(self.t("log_7"))
        self.log_range.pack(side="left")
        self.log_box = ctk.CTkTextbox(card, height=420, font=ctk.CTkFont(family="Consolas", size=13))
        self.log_box.pack(fill="both", expand=True, padx=16, pady=(0, 14))
        self._fill_log()

    def _fill_log(self) -> None:
        days = 30 if self.log_range.get() == self.t("log_30") else 7
        child = self.store.child()
        lines = [f"{self.t('col_date'):<12}{self.t('col_limit'):<12}{self.t('col_used'):<12}"
                 f"{self.t('col_ext'):<14}{self.t('col_result')}"]
        if child is not None:
            today = dt.date.today()
            for offset in range(days - 1, -1, -1):
                day = today - dt.timedelta(days=offset)
                status = day_status(self.store, child[0], day)
                if status.unlimited:
                    result = self.t("res_none")
                else:
                    result = self.t("res_limit") if status.exhausted else self.t("res_normal")
                limit = "–" if status.unlimited else f"{int(status.limit_s // 60)} Min."
                used = f"{int(status.used_s // 60)} Min."
                ext = f"{int(status.extension_s // 60)} Min."
                lines.append(f"{day.strftime('%d.%m.%Y'):<12}{limit:<12}{used:<12}{ext:<14}{result}")
        lines.append("")
        lines.append(self.t("events"))
        for ts, category, message in self.store.recent_audit(120):
            stamp = time.strftime("%d.%m.%Y %H:%M:%S", time.localtime(ts))
            lines.append(f"{stamp}  [{category}] {message}")
        self.log_box.configure(state="normal")
        self.log_box.delete("1.0", "end")
        self.log_box.insert("1.0", "\n".join(lines))
        self.log_box.configure(state="disabled")

    # ---------- Einstellungen ----------

    def _build_settings(self, page) -> None:
        pw = self._card(page, self.t("pw_change"))
        self.pw_old = ctk.CTkEntry(pw, show="•", width=320, placeholder_text=self.t("pw_old"))
        self.pw_old.pack(anchor="w", padx=16, pady=3)
        self.pw_new = ctk.CTkEntry(pw, show="•", width=320, placeholder_text=self.t("pw_new"))
        self.pw_new.pack(anchor="w", padx=16, pady=3)
        self.pw_repeat = ctk.CTkEntry(pw, show="•", width=320, placeholder_text=self.t("pw_repeat"))
        self.pw_repeat.pack(anchor="w", padx=16, pady=3)
        ctk.CTkButton(pw, text=self.t("pw_change"), width=200, fg_color=ACCENT,
                      command=self._change_password).pack(anchor="w", padx=16, pady=(8, 14))

        info = self._card(page, self.t("settings_data"))
        ctk.CTkLabel(info, text=paths.data_dir(), font=ctk.CTkFont(family="Consolas")).pack(anchor="w", padx=16)
        ctk.CTkLabel(info, text=f"{self.t('settings_version')}: {core.__version__}").pack(anchor="w", padx=16, pady=(4, 12))

        diag = self._card(page, self.t("diagnose"))
        self.diag_box = ctk.CTkTextbox(diag, height=220, font=ctk.CTkFont(family="Consolas", size=12))
        self.diag_box.pack(fill="both", expand=True, padx=16, pady=(0, 8))
        ctk.CTkButton(diag, text=self.t("diagnose_refresh"), width=220, fg_color=ACCENT,
                      command=self._update_diagnose).pack(anchor="w", padx=16, pady=(0, 14))
        self._update_diagnose()

        danger = self._card(page, self.t("uninstall"))
        ctk.CTkLabel(danger, text=self.t("uninstall_hint"), text_color=("gray35", "gray70"),
                     wraplength=760, justify="left").pack(anchor="w", padx=16, pady=(0, 4))
        ctk.CTkButton(danger, text=self.t("uninstall"), width=200, fg_color="#c0392b", hover_color="#962d22",
                      command=self._uninstall).pack(anchor="w", padx=16, pady=(6, 14))

    def _update_diagnose(self) -> None:
        lines = diagnose_lines(self.store, self.t)
        self.diag_box.configure(state="normal")
        self.diag_box.delete("1.0", "end")
        self.diag_box.insert("1.0", "\n".join(lines))
        self.diag_box.configure(state="disabled")

    def _change_password(self) -> None:
        stored = self.store.get("admin_password")
        if stored is None or not core.verify_password(self.pw_old.get(), stored):
            messagebox.showerror(self.t("error"), self.t("pw_wrong"))
            return
        new = self.pw_new.get()
        problem = core.password_problem(new)
        if problem:
            messagebox.showerror(self.t("error"), problem)
            return
        if new != self.pw_repeat.get():
            messagebox.showerror(self.t("error"), self.t("pw_mismatch"))
            return
        self.store.set("admin_password", core.hash_password(new))
        self.store.audit("Konfiguration", "Verwaltungspasswort geändert.")
        for entry in (self.pw_old, self.pw_new, self.pw_repeat):
            entry.delete(0, "end")
        messagebox.showinfo("Spaceprotect", self.t("pw_changed"))

    def _uninstall(self) -> None:
        if not messagebox.askyesno("Spaceprotect", self.t("uninstall_confirm")):
            return
        keep = False
        self.store.audit("Konfiguration", "Komplette Deinstallation gestartet.")
        self.store.close()
        try:
            installer.uninstall(keep_data=keep)
        except OSError as error:
            messagebox.showerror(self.t("error"), str(error))
            self.store = Store(paths.database_path())
            return
        messagebox.showinfo("Spaceprotect", self.t("uninstalled_ok"))
        if self.tray is not None:
            self.tray.stop()
        self.destroy()


def _tail(path: str, lines: int = 8) -> list[str]:
    try:
        with open(path, encoding="utf-8", errors="replace") as handle:
            content = handle.readlines()
    except OSError:
        return ["  (keine Datei)"]
    return ["  " + line.rstrip() for line in content[-lines:]] or ["  (leer)"]


def diagnose_lines(store: Store, t) -> list[str]:
    """Prüft Rechte, Datenbank, Dienst und Logs und liefert eine lesbare Übersicht."""
    lines = []
    lines.append(f"{t('diag_admin')}: {'ja' if winapi.is_admin() else 'NEIN (Programm als Administrator starten)'}")
    lines.append(f"{t('diag_datadir')}: {paths.data_dir()}")
    try:
        probe = os.path.join(paths.data_dir(), ".write_test")
        with open(probe, "w", encoding="utf-8") as handle:
            handle.write("ok")
        os.remove(probe)
        lines.append(f"{t('diag_writable')}: ja")
    except OSError as error:
        lines.append(f"{t('diag_writable')}: NEIN ({error})")
    try:
        count = store._read("SELECT COUNT(*) FROM settings")[0][0]
        lines.append(f"{t('diag_db')}: ja ({count} Einstellungen)")
    except Exception as error:  # noqa: BLE001 - Diagnose zeigt jeden Fehler an
        lines.append(f"{t('diag_db')}: NEIN ({error})")
    state = installer.service_state()
    lines.append(f"{t('diag_service')}: {state}")
    lines.append(f"{t('diag_exe')}: {'vorhanden' if os.path.exists(paths.installed_exe()) else 'fehlt'}")
    lines.append("")
    lines.append(t("diag_service_log"))
    lines.extend(_tail(os.path.join(paths.log_dir(), "spaceprotect.log")))
    lines.append(t("diag_gui_log"))
    lines.extend(_tail(os.path.join(paths.log_dir(), "gui-error.log")))
    return lines


def report_error(context: str, exc_info=None) -> None:
    """Schreibt den Fehler in gui-error.log. Ohne Fehlerinfo wird der aktuelle Fehler verwendet."""
    details = "".join(traceback.format_exception(*exc_info)) if exc_info else traceback.format_exc()
    try:
        os.makedirs(paths.log_dir(), exist_ok=True)
        with open(os.path.join(paths.log_dir(), "gui-error.log"), "a", encoding="utf-8") as log:
            log.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} {context}\n{details}\n")
    except OSError:
        pass


def _show_error(text: str) -> None:
    """Meldungsfenster ohne laufende Oberfläche (eigene, kurzlebige Tk-Instanz)."""
    root = tk.Tk()
    root.withdraw()
    messagebox.showerror("Spaceprotect", text, parent=root)
    root.destroy()


def run() -> None:
    if not winapi.is_admin():
        # Ohne Administratorrechte: UAC-Abfrage, danach startet sich die Verwaltung erhöht neu.
        # Das Kind kennt keine Admin-Zugangsdaten und kommt deshalb nicht weiter.
        ctypes.windll.shell32.ShellExecuteW(None, "runas", sys.executable, "", None, 1)
        return
    try:
        app = App()
    except Exception:  # noqa: BLE001
        report_error("Start der Verwaltung fehlgeschlagen")
        _show_error(translate("de", "crash"))
        return
    if app.cancelled:
        return
    app.mainloop()
