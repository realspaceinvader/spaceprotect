"""Symbole für Menü und Kopfzeile. Werden als Bilder gezeichnet, daher einheitlich auf jedem Windows."""

from __future__ import annotations

import math

from PIL import Image, ImageDraw

CANVAS = 64  # gezeichnet in hoher Auflösung, danach verkleinert (Kantenglättung)


def _canvas() -> tuple[Image.Image, ImageDraw.ImageDraw]:
    image = Image.new("RGBA", (CANVAS, CANVAS), (0, 0, 0, 0))
    return image, ImageDraw.Draw(image)


def _finish(image: Image.Image, size: int) -> Image.Image:
    return image.resize((size, size), Image.LANCZOS)


def sun(size: int = 18) -> Image.Image:
    image, draw = _canvas()
    color = (255, 190, 40, 255)
    center = CANVAS / 2
    for step in range(8):
        angle = math.radians(step * 45)
        draw.line(
            [(center + 21 * math.cos(angle), center + 21 * math.sin(angle)),
             (center + 30 * math.cos(angle), center + 30 * math.sin(angle))],
            fill=color, width=6)
    draw.ellipse([center - 16, center - 16, center + 16, center + 16], fill=color)
    return _finish(image, size)


def moon(size: int = 18) -> Image.Image:
    color = (255, 204, 80, 255)
    mask = Image.new("L", (CANVAS, CANVAS), 0)
    mask_draw = ImageDraw.Draw(mask)
    mask_draw.ellipse([8, 8, 56, 56], fill=255)
    mask_draw.ellipse([22, 3, 66, 47], fill=0)
    image = Image.new("RGBA", (CANVAS, CANVAS), color)
    image.putalpha(mask)
    return _finish(image, size)


def info(size: int = 18) -> Image.Image:
    image, draw = _canvas()
    draw.ellipse([4, 4, 60, 60], fill=(56, 132, 255, 255))
    white = (255, 255, 255, 255)
    draw.ellipse([27, 14, 37, 24], fill=white)
    draw.rounded_rectangle([27, 28, 37, 50], radius=4, fill=white)
    return _finish(image, size)


def close(size: int = 18) -> Image.Image:
    image, draw = _canvas()
    color = (226, 62, 74, 255)
    draw.line([(14, 14), (50, 50)], fill=color, width=9)
    draw.line([(50, 14), (14, 50)], fill=color, width=9)
    return _finish(image, size)


def hamburger(color: tuple[int, int, int, int], size: int = 22) -> Image.Image:
    image, draw = _canvas()
    for top in (12, 28, 44):
        draw.rounded_rectangle([10, top, 54, top + 8], radius=4, fill=color)
    return _finish(image, size)


def menu_icons(mode: str) -> dict[str, Image.Image]:
    """Symbole für Menüeinträge. mode ist 'Light' oder 'Dark'."""
    return {"sun": sun(), "moon": moon(), "info": info(), "close": close()}
