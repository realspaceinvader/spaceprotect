"""Installation, Deinstallation und Steuerung des Hintergrundprozesses.

Der Hintergrundprozess läuft als geplante Aufgabe unter SYSTEM (beim Start, mit automatischem Neustart).
Ein klassischer Windows-Dienst ist mit einer einzelnen PyInstaller-EXE nicht zuverlässig möglich,
weil die EXE intern einen zweiten Prozess startet und der Dienstmanager diesen nicht kennt.
Alle Funktionen hier benötigen Administratorrechte.
"""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
import tempfile
import time
from xml.sax.saxutils import escape

from . import paths
from .storage import Store

CREATE_NO_WINDOW = 0x08000000
TASK_NAME = "Spaceprotect"
LEGACY_SERVICE_NAME = "Spaceprotect"
HEARTBEAT_KEY = "service_heartbeat"
HEARTBEAT_MAX_AGE = 30.0
RUN_KEY = r"Software\Microsoft\Windows\CurrentVersion\Run"
RUN_VALUE = "Spaceprotect"


class InstallError(RuntimeError):
    pass


def _run(args: list[str]) -> subprocess.CompletedProcess:
    return subprocess.run(args, capture_output=True, text=True, creationflags=CREATE_NO_WINDOW)


def _schtasks(*args: str) -> subprocess.CompletedProcess:
    return _run(["schtasks.exe", *args])


# ---------- Status ----------

def task_exists() -> bool:
    return _schtasks("/Query", "/TN", TASK_NAME).returncode == 0


def _heartbeat_age() -> float | None:
    """Sekunden seit dem letzten Lebenszeichen des Hintergrundprozesses oder None."""
    try:
        store = Store(paths.database_path())
        try:
            raw = store.get(HEARTBEAT_KEY)
        finally:
            store.close()
        return None if raw is None else time.time() - float(raw)
    except Exception:  # noqa: BLE001 - Status darf nie abstürzen
        return None


def service_state() -> str:
    """'running', 'stopped' oder 'missing'. 'running' heißt: Lebenszeichen in den letzten 30 Sekunden."""
    if not task_exists():
        return "missing"
    age = _heartbeat_age()
    return "running" if age is not None and age <= HEARTBEAT_MAX_AGE else "stopped"


def is_installed() -> bool:
    return task_exists()


def service_log_tail(lines: int = 20) -> str:
    path = os.path.join(paths.log_dir(), "spaceprotect.log")
    try:
        with open(path, encoding="utf-8", errors="replace") as handle:
            content = handle.readlines()[-lines:]
    except OSError:
        return "(kein Dienstprotokoll gefunden)"
    return "".join(content).rstrip() or "(Dienstprotokoll ist leer)"


def service_failure_text() -> str:
    return "Der Schutz läuft nicht. Letzte Meldungen aus spaceprotect.log:\n\n" + service_log_tail()


# ---------- Steuerung ----------

def start_service() -> None:
    _schtasks("/Run", "/TN", TASK_NAME)


def stop_service() -> None:
    _schtasks("/End", "/TN", TASK_NAME)
    time.sleep(1.0)


def start_service_checked(wait_seconds: float = 12.0) -> None:
    """Startet den Schutz und prüft, ob er nach wait_seconds ein Lebenszeichen gibt. Sonst InstallError mit Protokoll."""
    start_service()
    deadline = time.time() + wait_seconds
    while time.time() < deadline:
        time.sleep(1.0)
        if service_state() == "running":
            return
    raise InstallError(service_failure_text())


# ---------- Rechte ----------

def _icacls(args: list[str], what: str) -> None:
    result = _run(["icacls", *args])
    if result.returncode != 0:
        raise InstallError(f"Rechte für {what} konnten nicht gesetzt werden:\n{result.stdout}{result.stderr}")


def _reset_children(path: str) -> None:
    """
    Bestehende Dateien und Unterordner erben wieder die Rechte des Ordners.
    WICHTIG: Rechte mit Vererbungsflags (OI)(CI) niemals rekursiv (/T) auf Dateien setzen. Das führt zu einer
    leeren Rechteliste, die Datei ist dann für niemanden mehr zugänglich (auch SQLite kann sie nicht öffnen).
    """
    if os.path.isdir(path) and os.listdir(path):
        _run(["icacls", os.path.join(path, "*"), "/reset", "/T", "/C"])


def _restrict_dir(path: str, users_may_read: bool, extra_sids: tuple[str, ...] = ()) -> None:
    """
    Nur der Ordner bekommt Rechte: SYSTEM und Administratoren Vollzugriff, Benutzer optional nur lesen/ausführen.
    Der Inhalt erbt diese Rechte. extra_sids ist nur für Tests gedacht.
    """
    args = [path, "/inheritance:r", "/grant:r", "*S-1-5-18:(OI)(CI)F", "*S-1-5-32-544:(OI)(CI)F"]
    if users_may_read:
        args.append("*S-1-5-32-545:(OI)(CI)RX")
    args.extend(f"*{sid}:(OI)(CI)F" for sid in extra_sids)
    _icacls(args, path)
    _reset_children(path)


def _restrict_exe(path: str) -> None:
    """Die Programmdatei bekommt explizite Rechte: Benutzer dürfen sie nur ausführen."""
    _icacls([path, "/inheritance:r", "/grant:r", "*S-1-5-18:F", "*S-1-5-32-544:F", "*S-1-5-32-545:RX"], path)


def ensure_data_access(extra_sids: tuple[str, ...] = ()) -> None:
    """
    Vollzugriff für SYSTEM und Administratoren auf den Datenordner; Dateien darin erben die Rechte neu.
    Repariert auch Dateien mit leerer Rechteliste. Funktioniert auch als SYSTEM.
    """
    data = paths.data_dir()
    os.makedirs(data, exist_ok=True)
    args = [data, "/grant:r", "*S-1-5-32-544:(OI)(CI)F", "*S-1-5-18:(OI)(CI)F"]
    args.extend(f"*{sid}:(OI)(CI)F" for sid in extra_sids)
    _icacls(args, data)
    _reset_children(data)


def repair_data_access() -> None:
    """Besitz am Datenordner zurückholen und Vollzugriff setzen (nur mit Administratorrechten)."""
    data = paths.data_dir()
    os.makedirs(data, exist_ok=True)
    _run(["takeown", "/F", data, "/R", "/D", "Y"])
    ensure_data_access()


# ---------- Autostart des Hinweis-Symbols ----------

def register_agent() -> None:
    """Das Hinweis-Symbol startet bei jeder Anmeldung eines Benutzers."""
    import winreg

    with winreg.CreateKeyEx(winreg.HKEY_LOCAL_MACHINE, RUN_KEY, 0, winreg.KEY_SET_VALUE) as key:
        winreg.SetValueEx(key, RUN_VALUE, 0, winreg.REG_SZ, f'"{paths.installed_exe()}" --agent')


def unregister_agent() -> None:
    import winreg

    try:
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, RUN_KEY, 0, winreg.KEY_SET_VALUE) as key:
            winreg.DeleteValue(key, RUN_VALUE)
    except OSError:
        pass  # war nicht gesetzt


# ---------- Geplante Aufgabe ----------

def _task_xml(exe: str) -> str:
    command = escape(exe)
    return f"""<?xml version="1.0" encoding="UTF-16"?>
<Task version="1.4" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">
  <RegistrationInfo>
    <Description>Spaceprotect: begrenzt die Computerzeit des Kinderkontos (läuft als SYSTEM).</Description>
  </RegistrationInfo>
  <Triggers>
    <BootTrigger>
      <Enabled>true</Enabled>
      <Delay>PT10S</Delay>
    </BootTrigger>
    <CalendarTrigger>
      <Repetition>
        <Interval>PT5M</Interval>
        <StopAtDurationEnd>false</StopAtDurationEnd>
      </Repetition>
      <StartBoundary>2024-01-01T00:00:00</StartBoundary>
      <Enabled>true</Enabled>
      <ScheduleByDay>
        <DaysInterval>1</DaysInterval>
      </ScheduleByDay>
    </CalendarTrigger>
  </Triggers>
  <Principals>
    <Principal id="Author">
      <UserId>S-1-5-18</UserId>
      <RunLevel>HighestAvailable</RunLevel>
    </Principal>
  </Principals>
  <Settings>
    <MultipleInstancesPolicy>IgnoreNew</MultipleInstancesPolicy>
    <DisallowStartIfOnBatteries>false</DisallowStartIfOnBatteries>
    <StopIfGoingOnBatteries>false</StopIfGoingOnBatteries>
    <AllowHardTerminate>true</AllowHardTerminate>
    <StartWhenAvailable>true</StartWhenAvailable>
    <RunOnlyIfNetworkAvailable>false</RunOnlyIfNetworkAvailable>
    <AllowStartOnDemand>true</AllowStartOnDemand>
    <Enabled>true</Enabled>
    <Hidden>false</Hidden>
    <RunOnlyIfIdle>false</RunOnlyIfIdle>
    <WakeToRun>false</WakeToRun>
    <ExecutionTimeLimit>PT0S</ExecutionTimeLimit>
    <Priority>6</Priority>
    <RestartOnFailure>
      <Interval>PT1M</Interval>
      <Count>999</Count>
    </RestartOnFailure>
  </Settings>
  <Actions Context="Author">
    <Exec>
      <Command>{command}</Command>
      <Arguments>--service</Arguments>
    </Exec>
  </Actions>
</Task>
"""


def _create_task(exe: str) -> None:
    handle, xml_path = tempfile.mkstemp(suffix=".xml")
    os.close(handle)
    try:
        with open(xml_path, "w", encoding="utf-16") as xml_file:
            xml_file.write(_task_xml(exe))
        result = _schtasks("/Create", "/TN", TASK_NAME, "/XML", xml_path, "/F")
    finally:
        try:
            os.remove(xml_path)
        except OSError:
            pass
    if result.returncode != 0:
        raise InstallError(f"Geplante Aufgabe konnte nicht angelegt werden:\n{result.stdout}{result.stderr}")


def _remove_legacy_service() -> None:
    """Entfernt einen Windows-Dienst aus früheren Versionen, falls vorhanden."""
    if _run(["sc.exe", "query", LEGACY_SERVICE_NAME]).returncode == 0:
        _run(["sc.exe", "stop", LEGACY_SERVICE_NAME])
        time.sleep(1.0)
        _run(["sc.exe", "delete", LEGACY_SERVICE_NAME])


def _replace_exe(source: str, target: str) -> None:
    """Kopiert die EXE. Läuft die alte noch, wird kurz gewartet."""
    last_error: Exception | None = None
    for _ in range(20):
        try:
            if os.path.exists(target):
                os.remove(target)
            shutil.copy2(source, target)
            return
        except OSError as error:
            last_error = error
            time.sleep(0.5)
    raise InstallError(f"Die Programmdatei ist in Benutzung und kann nicht ersetzt werden: {last_error}")


# ---------- Installation ----------

def install() -> None:
    """Kopiert die EXE in den Programmordner, setzt Rechte und richtet Aufgabe und Autostart ein."""
    if task_exists():
        stop_service()

    os.makedirs(paths.install_dir(), exist_ok=True)
    target = paths.installed_exe()
    source = os.path.abspath(sys.executable)
    if os.path.normcase(source) != os.path.normcase(os.path.abspath(target)):
        _replace_exe(source, target)

    os.makedirs(paths.data_dir(), exist_ok=True)
    if not os.environ.get(paths.OVERRIDE_ENV):
        # Reihenfolge: erst Programmordner (Benutzer: nur ausführen), dann Datenordner (Benutzer: kein Zugriff).
        _restrict_dir(paths.install_dir(), users_may_read=True)
        _restrict_exe(target)
        _restrict_dir(paths.data_dir(), users_may_read=False)

    _remove_legacy_service()
    _create_task(target)
    register_agent()
    start_service_checked()


def uninstall(keep_data: bool = False) -> None:
    """Entfernt Aufgabe, Autostart und Programmordner. Die laufende EXE löscht sich nach dem Beenden selbst."""
    unregister_agent()
    if task_exists():
        _schtasks("/End", "/TN", TASK_NAME)
        _schtasks("/Delete", "/TN", TASK_NAME, "/F")
    _remove_legacy_service()

    install_dir = paths.install_dir()
    exe = paths.installed_exe()
    cleanup = (f'ping 127.0.0.1 -n 3 > nul & taskkill /F /IM Spaceprotect.exe > nul 2>&1 & '
               f'ping 127.0.0.1 -n 2 > nul & del /f /q "{exe}" & ')
    if keep_data:
        cleanup += f'rmdir "{install_dir}"'
    else:
        cleanup += f'rmdir /s /q "{install_dir}"'
    subprocess.Popen(["cmd.exe", "/c", cleanup], creationflags=CREATE_NO_WINDOW)
