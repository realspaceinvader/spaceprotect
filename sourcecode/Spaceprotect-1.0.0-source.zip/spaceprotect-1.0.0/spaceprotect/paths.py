"""Speicherorte. Alles liegt im Programmordner: C:\\Program Files\\Spaceprotect (Daten in data\\).

SPACEPROTECT_DATA_DIR ist nur für Tests gedacht.
"""

from __future__ import annotations

import os
import sys

APP_NAME = "Spaceprotect"
OVERRIDE_ENV = "SPACEPROTECT_DATA_DIR"


def install_dir() -> str:
    return os.path.join(os.environ.get("ProgramFiles", r"C:\Program Files"), APP_NAME)


def installed_exe() -> str:
    return os.path.join(install_dir(), f"{APP_NAME}.exe")


def data_dir() -> str:
    override = os.environ.get(OVERRIDE_ENV)
    if override:
        return os.path.abspath(override)
    return os.path.join(install_dir(), "data")


def database_path() -> str:
    return os.path.join(data_dir(), "spaceprotect.db")


def log_dir() -> str:
    return os.path.join(data_dir(), "logs")


def resource_path(relative: str) -> str:
    """Pfad zu Dateien, die in die EXE gepackt wurden (PyInstaller) oder im Quellordner liegen."""
    base = getattr(sys, "_MEIPASS", os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    return os.path.join(base, relative)
