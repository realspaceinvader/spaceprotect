"""Hintergrundprozess (läuft als SYSTEM über die geplante Aufgabe): erfasst Zeit und erzwingt das Limit."""

from __future__ import annotations

import logging
import logging.handlers
import os
import sqlite3
import threading
import time
import traceback

import win32api
import win32event

from . import core, installer, paths, winapi
from .engine import Enforcer
from .storage import Store

ERROR_ALREADY_EXISTS = 183
HEARTBEAT_INTERVAL_SECONDS = 10.0


def _logger() -> logging.Logger:
    os.makedirs(paths.log_dir(), exist_ok=True)
    logger = logging.getLogger("spaceprotect")
    if not logger.handlers:
        handler = logging.handlers.RotatingFileHandler(
            os.path.join(paths.log_dir(), "spaceprotect.log"), maxBytes=2_000_000, backupCount=5, encoding="utf-8")
        handler.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s"))
        logger.addHandler(handler)
        logger.setLevel(logging.INFO)
    return logger


def _quarantine_database(log: logging.Logger) -> None:
    """Legt eine unbrauchbare Datenbank beiseite, damit der Schutz mit einer neuen starten kann."""
    stamp = time.strftime("%Y%m%d-%H%M%S")
    for suffix in ("", "-wal", "-shm"):
        source = paths.database_path() + suffix
        if os.path.exists(source):
            try:
                os.replace(source, f"{source}.defekt-{stamp}")
            except OSError:
                log.error("Datei konnte nicht beiseitegelegt werden: %s\n%s", source, traceback.format_exc())


def _open_store(log: logging.Logger) -> Store:
    """
    Öffnet die Datenbank. Schlägt das fehl:
    1. Datenrechte als SYSTEM reparieren und erneut versuchen.
    2. Bleibt sie unbrauchbar: beiseitelegen und neu anlegen (Schutz läuft weiter, Einstellungen müssen neu gesetzt werden).
    """
    try:
        return Store(paths.database_path())
    except sqlite3.Error:
        log.error("Datenbank nicht öffnbar, Datenrechte werden repariert:\n%s", traceback.format_exc())

    try:
        installer.ensure_data_access()
        return Store(paths.database_path())
    except (sqlite3.Error, installer.InstallError, OSError):
        log.error("Datenbank bleibt unbrauchbar, wird beiseitegelegt und neu angelegt:\n%s", traceback.format_exc())

    _quarantine_database(log)
    return Store(paths.database_path())


def run_enforcement(wait_or_stop) -> None:
    """
    Hauptschleife. wait_or_stop(sekunden) wartet und liefert True, sobald beendet werden soll.
    Einzelne Fehler werden protokolliert; die Schleife läuft weiter.
    """
    log = _logger()
    log.info("Datenbank wird geöffnet: %s", paths.database_path())
    store = _open_store(log)
    orphans = store.close_orphans()
    log.info("Datenbank bereit (%d unterbrochene Sitzung(en) geschlossen)", orphans)
    store.audit("Dienst", "Schutz gestartet." + (f" {orphans} unterbrochene Sitzung(en) geschlossen." if orphans else ""))

    enforcer: Enforcer | None = None
    current_sid: str | None = None
    rounds = 0
    last_heartbeat = 0.0
    last_error_audit = 0.0
    try:
        while True:
            child = None
            try:
                now = time.time()
                if now - last_heartbeat >= HEARTBEAT_INTERVAL_SECONDS:
                    store.set(installer.HEARTBEAT_KEY, str(now))
                    last_heartbeat = now

                child = store.child()
                sid = child[0] if child else None
                if sid != current_sid:
                    if enforcer is not None:
                        enforcer.shutdown()
                    enforcer = None
                    current_sid = sid
                    if sid is not None:
                        enforcer = Enforcer(store, sid, winapi.sessions_for_sid, winapi.logoff, winapi.show_message)
                        log.info("Überwachung aktiv für %s", child[1])
                if enforcer is not None:
                    enforcer.tick()
            except Exception as error:  # noqa: BLE001 - jede Runde ist isoliert, Fehler werden protokolliert
                log.error("Fehler in der Prüfrunde:\n%s", traceback.format_exc())
                if time.time() - last_error_audit >= 60.0:  # Ereignisprotokoll nicht fluten
                    last_error_audit = time.time()
                    try:
                        store.audit("Fehler", f"Fehler in der Prüfrunde: {type(error).__name__}: {error}")
                    except Exception:  # noqa: BLE001
                        pass
            rounds += 1
            if rounds % 60 == 0:  # etwa alle 5 Minuten ein Lebenszeichen im Protokoll
                log.info("Prüfschleife läuft (%d Runden)", rounds)
            if wait_or_stop(core.POLL_SECONDS):
                break
    finally:
        if enforcer is not None:
            enforcer.shutdown()
        store.audit("Dienst", "Schutz beendet.")
        store.close()
        log.info("Prüfschleife beendet")


def run_service_mode() -> None:
    """Einstiegspunkt der geplanten Aufgabe (--service). Läuft, bis der Prozess beendet wird."""
    log = _logger()
    # Nur eine Instanz: die Aufgabe startet alle 5 Minuten neu, falls der Prozess fehlt.
    mutex = win32event.CreateMutex(None, False, "Global\\SpaceprotectService")
    if win32api.GetLastError() == ERROR_ALREADY_EXISTS:
        log.info("Eine andere Instanz läuft bereits, diese wird beendet.")
        return

    log.info("Hintergrundprozess gestartet (PID %d)", os.getpid())
    stop = threading.Event()
    while True:
        try:
            run_enforcement(lambda seconds: stop.wait(seconds))
            break
        except Exception:  # noqa: BLE001
            log.error("Prüfschleife abgebrochen, neuer Versuch in 10 s:\n%s", traceback.format_exc())
            if stop.wait(10):
                break
    del mutex
