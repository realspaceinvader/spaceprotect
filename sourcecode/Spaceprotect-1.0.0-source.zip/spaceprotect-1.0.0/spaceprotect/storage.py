"""SQLite-Speicher. Autoritative Quelle für Nutzungszeit sind die Intervalle, Tagessummen werden nie gespeichert."""

from __future__ import annotations

import json
import os
import sqlite3
import time

from .core import DEFAULT_PLAN, DEFAULT_TEXTS, DayLimit, validate_plan

SCHEMA = """
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS intervals (
    id    INTEGER PRIMARY KEY AUTOINCREMENT,
    sid   TEXT NOT NULL,
    start REAL NOT NULL,
    end   REAL NOT NULL,
    open  INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS ix_intervals_sid ON intervals (sid, start);
CREATE TABLE IF NOT EXISTS extensions (
    id      INTEGER PRIMARY KEY AUTOINCREMENT,
    sid     TEXT NOT NULL,
    day     TEXT NOT NULL,
    minutes INTEGER NOT NULL CHECK (minutes > 0),
    op      TEXT NOT NULL UNIQUE
);
CREATE TABLE IF NOT EXISTS audit (
    id       INTEGER PRIMARY KEY AUTOINCREMENT,
    ts       REAL NOT NULL,
    category TEXT NOT NULL,
    message  TEXT NOT NULL
);
"""


class Store:
    def __init__(self, path: str) -> None:
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        self._db = sqlite3.connect(path, timeout=10)
        self._db.execute("PRAGMA journal_mode=WAL")
        self._db.executescript(SCHEMA)
        self._db.commit()

    def close(self) -> None:
        self._db.close()

    def _write(self, sql: str, params: tuple = ()) -> int:
        cursor = self._db.execute(sql, params)
        self._db.commit()
        return cursor.lastrowid or 0

    def _read(self, sql: str, params: tuple = ()) -> list[tuple]:
        return self._db.execute(sql, params).fetchall()

    # ---------- Einstellungen ----------

    def get(self, key: str, default: str | None = None) -> str | None:
        rows = self._read("SELECT value FROM settings WHERE key = ?", (key,))
        return rows[0][0] if rows else default

    def set(self, key: str, value: str) -> None:
        self._write("INSERT INTO settings (key, value) VALUES (?, ?) "
                    "ON CONFLICT(key) DO UPDATE SET value = excluded.value", (key, value))

    def get_json(self, key: str, default):
        raw = self.get(key)
        return default if raw is None else json.loads(raw)

    def set_json(self, key: str, value) -> None:
        self.set(key, json.dumps(value, ensure_ascii=False))

    def plan(self) -> tuple[DayLimit, ...]:
        raw = self.get_json("plan", None)
        if raw is None:
            return DEFAULT_PLAN
        return validate_plan([DayLimit(bool(enabled), int(minutes)) for enabled, minutes in raw])

    def save_plan(self, plan: tuple[DayLimit, ...]) -> None:
        self.set_json("plan", [[d.enabled, d.minutes] for d in validate_plan(plan)])

    def texts(self) -> dict:
        return {**DEFAULT_TEXTS, **self.get_json("texts", {})}

    def child(self) -> tuple[str, str] | None:
        raw = self.get_json("child", None)
        return (raw["sid"], raw["name"]) if raw else None

    def set_child(self, sid: str, name: str) -> None:
        self.set_json("child", {"sid": sid, "name": name})

    # ---------- Nutzungsintervalle ----------

    def open_interval(self, sid: str, start: float) -> int:
        return self._write("INSERT INTO intervals (sid, start, end, open) VALUES (?, ?, ?, 1)", (sid, start, start))

    def checkpoint(self, interval_id: int, end: float) -> None:
        self._write("UPDATE intervals SET end = ? WHERE id = ? AND open = 1", (end, interval_id))

    def close_interval(self, interval_id: int, end: float) -> None:
        self._write("UPDATE intervals SET end = ?, open = 0 WHERE id = ?", (end, interval_id))

    def close_orphans(self) -> int:
        """Schließt nach einem Absturz offene Intervalle auf dem letzten Checkpoint."""
        cursor = self._db.execute("UPDATE intervals SET open = 0 WHERE open = 1")
        self._db.commit()
        return cursor.rowcount

    def closed_intervals(self, sid: str, window_start: float, window_end: float) -> list[tuple[float, float]]:
        return [(s, e) for s, e in self._read(
            "SELECT start, end FROM intervals WHERE sid = ? AND open = 0 AND end > ? AND start < ?",
            (sid, window_start, window_end))]

    def all_intervals(self, sid: str, window_start: float, window_end: float) -> list[tuple[float, float]]:
        """Inklusive laufender Intervalle (Ende = letzter Checkpoint). Nur für Anzeige."""
        return [(s, e) for s, e in self._read(
            "SELECT start, end FROM intervals WHERE sid = ? AND end > ? AND start < ?",
            (sid, window_start, window_end))]

    # ---------- Verlängerungen ----------

    def add_extension(self, sid: str, day: str, minutes: int, op: str) -> bool:
        """False, wenn dieselbe Operation schon gebucht wurde (keine Doppelbuchung)."""
        try:
            self._write("INSERT INTO extensions (sid, day, minutes, op) VALUES (?, ?, ?, ?)",
                        (sid, day, minutes, op))
        except sqlite3.IntegrityError:
            return False
        return True

    def extension_minutes(self, sid: str, day: str) -> int:
        rows = self._read("SELECT COALESCE(SUM(minutes), 0) FROM extensions WHERE sid = ? AND day = ?", (sid, day))
        return int(rows[0][0])

    # ---------- Protokoll ----------

    def audit(self, category: str, message: str) -> None:
        self._write("INSERT INTO audit (ts, category, message) VALUES (?, ?, ?)", (time.time(), category, message))

    def recent_audit(self, limit: int = 200) -> list[tuple[float, str, str]]:
        return self._read("SELECT ts, category, message FROM audit ORDER BY id DESC LIMIT ?", (limit,))
