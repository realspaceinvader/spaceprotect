"""Windows-Schnittstelle: Sitzungen (WTS), Abmeldung, Hinweise, Konten."""

from __future__ import annotations

import ctypes
import ctypes.wintypes as wt
import os
import winreg

import pywintypes
import win32api
import win32net
import win32security

WTS_USER_NAME = 5
WTS_DOMAIN_NAME = 7
WTS_STATE_ACTIVE = 0
WTS_STATE_CONNECTED = 1
WTS_STATE_SHADOW = 3
WTS_STATE_DISCONNECTED = 4
LOGGED_ON_STATES = {WTS_STATE_ACTIVE, WTS_STATE_CONNECTED, WTS_STATE_SHADOW, WTS_STATE_DISCONNECTED}
MB_OK_WARNING_TOPMOST = 0x0 | 0x30 | 0x40000

_wtsapi = ctypes.WinDLL("wtsapi32", use_last_error=True)


class _WtsSessionInfo(ctypes.Structure):
    _fields_ = [("SessionId", wt.DWORD), ("pWinStationName", wt.LPWSTR), ("State", wt.DWORD)]


_WTSEnumerateSessionsW = _wtsapi.WTSEnumerateSessionsW
_WTSEnumerateSessionsW.argtypes = [wt.HANDLE, wt.DWORD, wt.DWORD,
                                   ctypes.POINTER(ctypes.POINTER(_WtsSessionInfo)), ctypes.POINTER(wt.DWORD)]
_WTSEnumerateSessionsW.restype = wt.BOOL

_WTSQuerySessionInformationW = _wtsapi.WTSQuerySessionInformationW
_WTSQuerySessionInformationW.argtypes = [wt.HANDLE, wt.DWORD, ctypes.c_int,
                                         ctypes.POINTER(ctypes.c_void_p), ctypes.POINTER(wt.DWORD)]
_WTSQuerySessionInformationW.restype = wt.BOOL

_WTSFreeMemory = _wtsapi.WTSFreeMemory
_WTSFreeMemory.argtypes = [ctypes.c_void_p]
_WTSFreeMemory.restype = None

_WTSLogoffSession = _wtsapi.WTSLogoffSession
_WTSLogoffSession.argtypes = [wt.HANDLE, wt.DWORD, wt.BOOL]
_WTSLogoffSession.restype = wt.BOOL

_WTSSendMessageW = _wtsapi.WTSSendMessageW
_WTSSendMessageW.argtypes = [wt.HANDLE, wt.DWORD, wt.LPWSTR, wt.DWORD, wt.LPWSTR, wt.DWORD,
                             wt.DWORD, wt.DWORD, ctypes.POINTER(wt.DWORD), wt.BOOL]
_WTSSendMessageW.restype = wt.BOOL


def is_admin() -> bool:
    return bool(ctypes.windll.shell32.IsUserAnAdmin())


def _enumerate_sessions() -> list[tuple[int, int]]:
    info_ptr = ctypes.POINTER(_WtsSessionInfo)()
    count = wt.DWORD(0)
    if not _WTSEnumerateSessionsW(None, 0, 1, ctypes.byref(info_ptr), ctypes.byref(count)):
        raise ctypes.WinError(ctypes.get_last_error())
    try:
        return [(info_ptr[i].SessionId, info_ptr[i].State) for i in range(count.value)]
    finally:
        _WTSFreeMemory(ctypes.cast(info_ptr, ctypes.c_void_p))


def _query_string(session_id: int, info_class: int) -> str:
    buffer = ctypes.c_void_p()
    size = wt.DWORD(0)
    if not _WTSQuerySessionInformationW(None, session_id, info_class, ctypes.byref(buffer), ctypes.byref(size)):
        return ""
    try:
        return ctypes.wstring_at(buffer.value) if buffer.value else ""
    finally:
        _WTSFreeMemory(buffer)


def logged_on_sessions() -> list[tuple[int, str, str]]:
    """Liste (Sitzungs-ID, SID, Benutzername) aller angemeldeten Benutzersitzungen."""
    result = []
    computer = win32api.GetComputerName()
    for session_id, state in _enumerate_sessions():
        if state not in LOGGED_ON_STATES:
            continue
        user = _query_string(session_id, WTS_USER_NAME)
        if not user:
            continue
        domain = _query_string(session_id, WTS_DOMAIN_NAME) or computer
        try:
            sid, _, _ = win32security.LookupAccountName(domain, user)
        except pywintypes.error:
            continue
        result.append((session_id, win32security.ConvertSidToStringSid(sid), user))
    return result


def sessions_for_sid(sid: str) -> list[int]:
    return [sid_id for sid_id, s, _ in logged_on_sessions() if s.upper() == sid.upper()]


def logoff(session_id: int) -> bool:
    return bool(_WTSLogoffSession(None, session_id, False))


def show_message(session_id: int, text: str, title: str = "Spaceprotect") -> bool:
    """Zeigt einen Hinweis auf dem Desktop der Sitzung (blockiert nicht). Signatur passt zur Engine: (Sitzung, Text)."""
    response = wt.DWORD(0)
    return bool(_WTSSendMessageW(None, session_id, title, len(title) * 2, text, len(text) * 2,
                                 MB_OK_WARNING_TOPMOST, 0, ctypes.byref(response), False))


def current_user_sid() -> str:
    token = win32security.OpenProcessToken(win32api.GetCurrentProcess(), win32security.TOKEN_QUERY)
    return win32security.ConvertSidToStringSid(win32security.GetTokenInformation(token, win32security.TokenUser)[0])


def admin_sids() -> set[str]:
    group_sid = win32security.ConvertStringSidToSid("S-1-5-32-544")
    group_name, _, _ = win32security.LookupAccountSid(None, group_sid)
    members, _, _ = win32net.NetLocalGroupGetMembers(None, group_name, 2)
    return {win32security.ConvertSidToStringSid(m["sid"]).upper() for m in members}


def standard_accounts() -> list[tuple[str, str]]:
    """Lokale Standardkonten als (SID, Name). Administratoren und das aktuelle Konto fehlen absichtlich."""
    excluded = admin_sids() | {current_user_sid().upper()}
    accounts = []
    key_path = r"SOFTWARE\Microsoft\Windows NT\CurrentVersion\ProfileList"
    with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, key_path) as root:
        index = 0
        while True:
            try:
                sid = winreg.EnumKey(root, index)
            except OSError:
                break
            index += 1
            if not sid.upper().startswith("S-1-5-21-") or sid.upper() in excluded:
                continue
            try:
                with winreg.OpenKey(root, sid) as profile:
                    path, _ = winreg.QueryValueEx(profile, "ProfileImagePath")
            except OSError:
                continue
            accounts.append((sid.upper(), os.path.basename(os.path.expandvars(path))))
    return sorted(accounts, key=lambda a: a[1].lower())


def account_name(sid: str) -> str:
    try:
        name, domain, _ = win32security.LookupAccountSid(None, win32security.ConvertStringSidToSid(sid))
        return name
    except pywintypes.error:
        return sid
