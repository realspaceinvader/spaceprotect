import datetime as dt

import pytest

from spaceprotect import core
from spaceprotect.core import ConfigError, DayLimit


def test_merge_gleichzeitige_sitzungen_zaehlen_einmal():
    assert core.used_seconds([(0, 600), (0, 600)], 0, 3600) == 600


def test_used_seconds_schneidet_an_mitternacht():
    assert core.used_seconds([(-1800, 2700)], 0, 86400) == 2700


def test_budget_exakt_erreicht_ist_aufgebraucht():
    status = core.evaluate_budget(DayLimit(True, 120), 0, 120 * 60)
    assert status.exhausted
    assert status.remaining_s == 0


def test_budget_verlaengerung_erhoeht_nur_den_tag():
    status = core.evaluate_budget(DayLimit(True, 120), 30, 120 * 60)
    assert not status.exhausted
    assert status.remaining_s == 30 * 60


def test_limit_null_erlaubt_keine_zeit():
    assert core.evaluate_budget(DayLimit(True, 0), 0, 0).exhausted


def test_deaktiviertes_limit_ist_unbegrenzt():
    status = core.evaluate_budget(DayLimit(False, 0), 0, 99999)
    assert status.unlimited and not status.exhausted


def test_warnung_zehn_minuten_nur_einmal():
    shown: set[int] = set()
    assert core.next_warning(9 * 60, shown, [10, 2]) == 10
    assert core.next_warning(8 * 60, shown, [10, 2]) is None


def test_nur_drei_minuten_uebrig_zeigt_aktuelle_restzeit():
    shown: set[int] = set()
    assert core.next_warning(3 * 60, shown, [10, 2]) == 10
    assert core.render_text("Noch {RestMinuten} Minuten.", 3 * 60) == "Noch 3 Minuten."
    assert core.next_warning(90, shown, [10, 2]) == 2


def test_plan_braucht_sieben_tage():
    with pytest.raises(ConfigError):
        core.validate_plan(core.DEFAULT_PLAN[:6])


def test_limit_ueber_24_stunden_ungueltig():
    with pytest.raises(ConfigError):
        DayLimit(True, 1441).validate()


def test_passwort_wird_nicht_im_klartext_gespeichert():
    stored = core.hash_password("Sehr-Geheim-2026")
    assert "Sehr-Geheim-2026" not in stored
    assert core.verify_password("Sehr-Geheim-2026", stored)
    assert not core.verify_password("Sehr-Geheim-2027", stored)


def test_passwort_stärke():
    assert core.password_problem("kurz") is not None
    assert core.password_problem("nurkleinbuchstaben") is not None
    assert core.password_problem("Starkes-Passwort-2026") is None


def test_day_window_ist_24_stunden_ausser_umstellung():
    start, end = core.day_window(dt.date(2026, 10, 11))
    assert 23 * 3600 <= end - start <= 25 * 3600
