"""Regressionstest: Rechte auf dem Datenordner dürfen die Datenbank nie unbrauchbar machen.

Fehler der Vorversion: `icacls <Ordner> /inheritance:r /grant:r ...:(OI)(CI)F /T` erzeugte auf Dateien eine
leere Rechteliste, danach konnte niemand (auch nicht SYSTEM) die Datenbank mehr öffnen.
"""

import os
import sqlite3
import subprocess

import pytest

from spaceprotect import installer, paths, winapi

CREATE_NO_WINDOW = 0x08000000


def _can_use(db_path: str) -> bool:
    try:
        con = sqlite3.connect(db_path, timeout=2)
        con.execute("PRAGMA journal_mode=WAL")
        con.execute("CREATE TABLE IF NOT EXISTS t (x)")
        con.execute("INSERT INTO t VALUES (1)")
        con.commit()
        con.close()
        return True
    except sqlite3.Error:
        return False


@pytest.fixture
def data_dir(tmp_path, monkeypatch):
    target = tmp_path / "data"
    target.mkdir()
    monkeypatch.setenv(paths.OVERRIDE_ENV, str(target))
    return target


def test_alter_befehl_erzeugt_unbrauchbare_datei_und_reparatur_stellt_her(data_dir):
    me = winapi.current_user_sid()
    db = str(data_dir / "spaceprotect.db")
    assert _can_use(db)

    # Der fehlerhafte Befehl der Vorversion (zusätzlich mit meinem Konto, damit der Test mich nicht aussperrt).
    subprocess.run(
        ["icacls", str(data_dir), "/inheritance:r", "/grant:r",
         "*S-1-5-18:(OI)(CI)F", "*S-1-5-32-544:(OI)(CI)F", f"*{me}:(OI)(CI)F", "/T"],
        capture_output=True, text=True, creationflags=CREATE_NO_WINDOW, check=True)
    assert not _can_use(db), "Der alte Befehl muss die Datei unbrauchbar machen (sonst testet dieser Test nichts)"

    installer.ensure_data_access(extra_sids=(me,))

    assert _can_use(db)


def test_neue_rechte_lassen_datenbank_nutzbar(data_dir):
    me = winapi.current_user_sid()
    db = str(data_dir / "spaceprotect.db")
    assert _can_use(db)

    installer._restrict_dir(str(data_dir), users_may_read=False, extra_sids=(me,))

    assert _can_use(db)
    # Neu angelegte Dateien erben ebenfalls (z. B. -wal und -shm).
    assert os.path.exists(db + "-wal") or _can_use(db)
