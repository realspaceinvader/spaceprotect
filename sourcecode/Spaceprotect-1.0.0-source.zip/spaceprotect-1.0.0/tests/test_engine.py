import pytest

from spaceprotect import core
from spaceprotect.core import DayLimit
from spaceprotect.engine import Enforcer
from spaceprotect.storage import Store

CHILD = "S-1-5-21-1-2-3-1001"


class Clock:
    def __init__(self):
        self.now = 1_800_000_000.0  # fester Startzeitpunkt, Wand- und Monotonuhr laufen gleich

    def advance(self, seconds):
        self.now += seconds

    def __call__(self):
        return self.now


class World:
    """Simuliert Sitzungen und Abmeldungen des Kinderkontos."""

    def __init__(self):
        self.sessions: list[int] = []
        self.logoffs: list[int] = []
        self.messages: list[str] = []
        self.logoff_ok = True

    def list_sessions(self, sid):
        return list(self.sessions)

    def logoff(self, session_id):
        self.logoffs.append(session_id)
        return self.logoff_ok

    def message(self, session_id, text):
        self.messages.append(text)
        return True


@pytest.fixture
def setup(tmp_path, monkeypatch):
    store = Store(str(tmp_path / "test.db"))
    clock = Clock()
    world = World()
    # Ein Tag mit 10 Minuten Limit an allen Wochentagen.
    store.save_plan(tuple(DayLimit(True, 10) for _ in range(7)))
    enforcer = Enforcer(store, CHILD, world.list_sessions, world.logoff, world.message,
                        wall=clock, mono=clock)
    # Tests starten mitten am Tag, damit der Kalendertag nicht gerade wechselt.
    monkeypatch.setattr(core, "POLL_SECONDS", 5.0)
    yield store, clock, world, enforcer
    store.close()


def run(clock, enforcer, seconds, step=5):
    for _ in range(int(seconds // step)):
        clock.advance(step)
        enforcer.tick()


def test_budget_erreicht_meldet_nach_grace_ab(setup):
    store, clock, world, enforcer = setup
    world.sessions = [2]
    run(clock, enforcer, 10 * 60 + 30)
    assert 2 in world.logoffs


def test_erneute_anmeldung_bei_verbrauchtem_budget_sofort(setup):
    store, clock, world, enforcer = setup
    world.sessions = [2]
    run(clock, enforcer, 11 * 60)
    world.sessions = []
    run(clock, enforcer, 60)
    world.logoffs.clear()
    world.sessions = [3]
    run(clock, enforcer, 10)
    assert 3 in world.logoffs


def test_schlaf_wird_nicht_gezaehlt(setup):
    store, clock, world, enforcer = setup
    world.sessions = [2]
    run(clock, enforcer, 5 * 60)
    clock.advance(2 * 3600)  # Ruhezustand ohne Prüfung
    enforcer.tick()
    run(clock, enforcer, 4 * 60)
    assert world.logoffs == []


def test_abmeldung_wird_nach_fuenf_versuchen_abgebrochen(setup):
    store, clock, world, enforcer = setup
    world.logoff_ok = False
    world.sessions = [2]
    run(clock, enforcer, 15 * 60)
    assert len(world.logoffs) == core.MAX_LOGOFF_ATTEMPTS


def test_verlaengerung_nimmt_abmeldung_zurueck(setup):
    store, clock, world, enforcer = setup
    world.sessions = [2]
    run(clock, enforcer, 10 * 60 + 30)
    assert world.logoffs
    assert store.add_extension(CHILD, clock_day(clock), 30, "op-1")
    world.logoffs.clear()
    run(clock, enforcer, 60)
    assert world.logoffs == []


def test_doppelte_verlaengerung_wird_nicht_doppelt_gebucht(setup):
    store, clock, world, enforcer = setup
    assert store.add_extension(CHILD, clock_day(clock), 15, "same")
    assert not store.add_extension(CHILD, clock_day(clock), 15, "same")
    assert store.extension_minutes(CHILD, clock_day(clock)) == 15


def test_gleichzeitige_sitzungen_zaehlen_nur_einmal(setup):
    store, clock, world, enforcer = setup
    world.sessions = [2, 4]
    run(clock, enforcer, 8 * 60)
    assert world.logoffs == []


def test_meldungsfehler_unterbricht_zeiterfassung_und_abmeldung_nicht(setup):
    """Regression: Ein fehlerhafter Meldungs-Callback ließ die Sitzung bei jedem Durchlauf neu beginnen."""
    store, clock, world, _ = setup

    def broken_message(session_id, text):
        raise TypeError("Meldung nicht anzeigbar")

    enforcer = Enforcer(store, CHILD, world.list_sessions, world.logoff, broken_message, wall=clock, mono=clock)
    world.sessions = [2]
    run(clock, enforcer, 11 * 60)

    assert 2 in world.logoffs, "Abmeldung muss trotz fehlerhafter Meldung erfolgen"
    start, end = core.day_window(__import__("datetime").datetime.fromtimestamp(clock.now).date())
    used = core.used_seconds(store.all_intervals(CHILD, start, end), start, end)
    assert used > 9 * 60, "Zeit muss weiter gezählt werden, nicht bei jedem Durchlauf neu beginnen"
    logins = [row for row in store.recent_audit(500) if row[1] == "Anmeldung"]
    assert len(logins) == 1, "Die Anmeldung darf nur einmal erkannt werden"


def test_echte_windows_funktionen_haben_zur_engine_passende_signatur():
    """Regression: show_message(session_id, title, text) wurde mit (session_id, text) aufgerufen -> TypeError."""
    import inspect

    from spaceprotect import winapi

    inspect.signature(winapi.show_message).bind(1, "Text")
    inspect.signature(winapi.logoff).bind(1)
    inspect.signature(winapi.sessions_for_sid).bind("S-1-5-21-1")


def test_engine_mit_den_echten_funktionen_zaehlt_zeit_ohne_fehler(setup):
    """
    Verdrahtung wie im Dienst, aber mit ungültiger Sitzungs-ID (99999): es wird nichts angezeigt und niemand abgemeldet.
    Limit 1 Minute löst sofort Warnungen und später die Abmeldung aus, also laufen echte Meldungs- und Abmelde-Aufrufe.
    """
    from spaceprotect import winapi

    store, clock, world, _ = setup
    store.save_plan(tuple(DayLimit(True, 1) for _ in range(7)))
    enforcer = Enforcer(store, CHILD, lambda sid: [99999], winapi.logoff, winapi.show_message, wall=clock, mono=clock)

    run(clock, enforcer, 90)

    errors = [row for row in store.recent_audit(500) if row[1] == "Fehler" and "TypeError" in row[2]]
    assert errors == []
    start, end = core.day_window(__import__("datetime").datetime.fromtimestamp(clock.now).date())
    assert core.used_seconds(store.all_intervals(CHILD, start, end), start, end) >= 50


def clock_day(clock):
    import datetime as dt
    return dt.datetime.fromtimestamp(clock.now).date().isoformat()
